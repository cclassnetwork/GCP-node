package net.globalchat.p2p;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.util.regex.Pattern;

/**
 * Global Chat P2P. The whole peer-to-peer engine runs inside this app (embedded Python started through
 * gc_android.py). The screens are web pages served by the engine on 127.0.0.1 and shown in the system WebView.
 * Nothing is loaded from the Internet, and there is no chat server.
 */
public class MainActivity extends Activity {
    private ValueCallback<Uri[]> chooser;

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 4711 && chooser != null) {
            Uri[] r = (res == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            chooser.onReceiveValue(r);
            chooser = null;
        }
    }

    static volatile boolean visible = false;
    private static final Pattern ROUTE = Pattern.compile("^(group|chat/gc[a-z2-7]{32})$");

    private WebView web;
    private String origin;       // http://127.0.0.1:PORT
    private String base;         // origin + /ui/TOKEN/
    private String pendingRoute;
    private ConnectivityManager.NetworkCallback netCb;
    private boolean clearHistory;   // drop the "Starting..." page so Back does not return to it

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE); // no screenshots of chats
        web = new WebView(this);
        web.setBackgroundColor(0xFF0A1020);
        setContentView(web);
        configureWebView();
        pendingRoute = routeFrom(getIntent());
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7);
        startEngine();
    }

    private static String routeFrom(Intent i) {
        String r = i == null ? null : i.getStringExtra("route");
        return r != null && ROUTE.matcher(r).matches() ? r : null;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String r = routeFrom(intent);
        if (r != null && base != null) web.loadUrl(base + "#/" + r);
        else if (r != null) pendingRoute = r;
    }

    private void startEngine() {
        showPage("Starting Global Chat...", "The first start takes a little longer while your keys are prepared.");
        final String dataDir = getFilesDir().getAbsolutePath() + "/gcp2p";
        final Context app = getApplicationContext();
        new Thread(() -> {
            try {
                String keyHex = KeystoreVault.storageKeyHex(app);
                if (!Python.isStarted()) Python.start(new AndroidPlatform(app));
                String endpoint = Python.getInstance().getModule("gc_android")
                        .callAttr("start", dataDir, keyHex, new Notifier(app), 60, BuildConfig.NODE_MODE).toString();      // "port:token"
                final String[] p = endpoint.split(":");
                runOnUiThread(() -> {
                    origin = "http://127.0.0.1:" + p[0];
                    base = origin + "/ui/" + p[1] + "/";
                    clearHistory = true;
                    web.loadUrl(pendingRoute != null ? base + "#/" + pendingRoute : base);
                    pendingRoute = null;
                    startNodeService();
                    watchNetwork();
                });
            } catch (Throwable t) {
                String why = String.valueOf(t);
                if (why.length() > 800) why = why.substring(0, 800);
                final String msg = why;
                runOnUiThread(() -> showPage("Global Chat could not start", msg
                        + "\n\nPlease send this text to the developer. Your messages are not affected."));
            }
        }, "gcp2p-engine").start();
    }

    private void startNodeService() {
        try {
            Intent s = new Intent(this, P2PService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        } catch (Throwable ignored) { /* the app still works in the foreground */ }
    }

    /** When Wi-Fi or mobile data changes, tell the engine so peers are re-dialled immediately. */
    private void watchNetwork() {
        if (netCb != null) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            netCb = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network n) { kick(); }
                @Override public void onLinkPropertiesChanged(Network n, android.net.LinkProperties lp) { kick(); }
            };
            cm.registerDefaultNetworkCallback(netCb);
        } catch (Throwable ignored) { netCb = null; }
    }

    private void kick() {
        new Thread(() -> {
            try { Python.getInstance().getModule("gc_android").callAttr("kick"); } catch (Throwable ignored) { }
        }, "gcp2p-kick").start();
    }

    private void showPage(String title, String text) {
        String html = "<html><body style='font-family:sans-serif;background:#0a1020;color:#e8f0ff;padding:24px'>"
                + "<h2>" + TextUtils.htmlEncode(title) + "</h2><p style='white-space:pre-wrap'>"
                + TextUtils.htmlEncode(text) + "</p></body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    private void configureWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        s.setGeolocationEnabled(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.addJavascriptInterface(new Host(), "GCHost");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String u = request.getUrl().toString();
                return !(origin != null && (u.equals(origin) || u.startsWith(origin + "/")));   // never leave the local engine
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (clearHistory && base != null && url != null && url.startsWith(base)) { view.clearHistory(); clearHistory = false; }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && origin != null)
                    showPage("Global Chat is not responding", "Close the app completely and open it again.");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
                    startActivityForResult(Intent.createChooser(i, "Photo or video"), 4711);
                } catch (Exception e) {
                    chooser = null;
                    cb.onReceiveValue(null);
                }
                return true;
            }
        });
    }

    /** Small bridge for the More screen. Only pages from the local engine are ever loaded in this WebView. */
    private class Host {
        @JavascriptInterface
        public void batterySettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
                catch (Throwable t) {
                    try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))); }
                    catch (Throwable ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void openUrl(String url) {
            if (url == null || !url.matches("^http://127\\.0\\.0\\.1:[0-9]{2,5}/?$")) return;   // only this phone's own dashboard
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable ignored) { }
            });
        }

        @JavascriptInterface
        public void quit() {
            runOnUiThread(() -> {
                try { stopService(new Intent(MainActivity.this, P2PService.class)); } catch (Throwable ignored) { }
                try { Python.getInstance().getModule("gc_android").callAttr("stop"); } catch (Throwable ignored) { }
                finishAndRemoveTask();
                Process.killProcess(Process.myPid());
            });
        }
    }

    @Override protected void onResume() { super.onResume(); visible = true; kick(); }
    @Override protected void onPause() { visible = false; super.onPause(); }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else moveTaskToBack(true);   // keep running in the background
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
