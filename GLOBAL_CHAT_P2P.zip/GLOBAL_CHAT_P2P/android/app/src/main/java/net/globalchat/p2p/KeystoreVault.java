package net.globalchat.p2p;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.security.KeyStore;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Device-bound storage key. A random 32-byte secret is encrypted with an AES key that lives in the Android Keystore
 * (it cannot be exported), and only the encrypted form is kept in app storage. The Python engine uses the secret to
 * encrypt the identity private keys in its database, so copying the app's files off the phone does not reveal them.
 */
final class KeystoreVault {
    private static final String ALIAS = "gcp2p_storage_key_v1";
    private static final String PREFS = "vault";
    private static final String ITEM = "k";

    private KeystoreVault() {}

    static synchronized String storageKeyHex(Context ctx) throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            kg.generateKey();
        }
        SecretKey key = (SecretKey) ks.getKey(ALIAS, null);
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String blob = p.getString(ITEM, null);
        byte[] raw;
        if (blob == null) {
            raw = new byte[32];
            new SecureRandom().nextBytes(raw);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.ENCRYPT_MODE, key);
            byte[] ct = c.doFinal(raw);
            String stored = Base64.encodeToString(c.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
            if (!p.edit().putString(ITEM, stored).commit()) throw new IllegalStateException("could not save the key");
        } else {
            String[] parts = blob.split(":");
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)));
            raw = c.doFinal(Base64.decode(parts[1], Base64.NO_WRAP));
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : raw) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
