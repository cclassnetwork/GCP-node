# Security notes

**This app has not had an independent security review. Do not rely on it where lives or liberty depend on it.**

## What is protected
* **Content of private messages**: end-to-end encrypted (X25519 + HKDF + ChaCha20-Poly1305), signed by the sender.
  Relays, mailbox holders and network observers cannot read it.
* **Identity**: Ed25519; peer ID derived from the keys; presence records and group messages are signed, so usernames
  and identities cannot be forged. Replays are rejected by IDs and time windows.
* **Keys at rest**: encrypted with a secret that is wrapped by the Android Keystore.
* **Local engine API**: loopback only, per-launch random token, Host check, strict CSP, no external requests.
* **Abuse**: token-bucket rate limits on messages and requests, message size limits, temporary bans for peers that send
  invalid data, bounded relay and mailbox resources.
* **Screens**: screenshots and the recent-apps preview are blocked (FLAG_SECURE).

## What is NOT protected
* **Metadata**: peers you connect to see your IP address and when you are online. Relays see who talks to whom (peer IDs)
  and when. This is not an anonymity network like Tor. "Anonymous" here means no phone/email/real-name account.
* **Map location** is opt-in, coarse (about 11 km) and visible to every peer, not only the dashboard. Do not share it if your
  location is sensitive. The node never derives locations from IP addresses.
* **The global group** is public to everyone in it.
* **Contact verification**: compare fingerprints (Security screen) over another channel to defeat impersonation.
* **Lost phone / uninstall**: the identity exists only on the phone. Uninstalling or "Delete identity" destroys it; there
  is no recovery and no backup (Android backup is disabled on purpose).
* **A rooted or compromised phone** can read keys while the app runs.
* **Denial of service**: a determined attacker with many identities can still cause load; limits only bound it.
* **Sybil attacks** on the DHT are not fully defended.

## Reporting
Treat unexpected behaviour as a bug; keep the exact text of any error screen.

## Photos, videos and "view once" - honest limits

- Media is end-to-end encrypted and encrypted at rest on both phones; the type is checked from the file's bytes, not its name.
- **View once is a courtesy, not a guarantee.** Nobody can stop the receiver photographing the screen with another phone, screen-recording
  where the OS allows it, or running a modified app that keeps the bytes. The app itself blocks screenshots (FLAG_SECURE) and deletes the file after one view.
- The sender's phone must be online for the receiver to fetch the file; there is no server holding big files. Offers expire after 7 days.
- Media is private-chat only, and the sender cannot recall a file already received.
