# Testing

## Automated (one machine, real sockets)
    bash scripts/run_tests.sh

| Area | What is checked |
|---|---|
| Anonymous identity | keys generated, peer ID derived, stored encrypted, restart keeps the same ID, wrong device key cannot open it |
| Username changes | validation, change keeps the peer ID, others see the new name |
| Encryption / signatures | round trips, tampering rejected, wrong recipient cannot decrypt, forged signatures rejected |
| Peer discovery | DHT lookups across several nodes, online / unreachable / offline states, signed presence expiry, forged presence rejected, LAN beacons |
| Two-peer connection | mutual authentication, wrong-peer rejection, garbage and tampered traffic rejected |
| Private messages | end-to-end delivery, delivery status, duplicate stored once, forged message rejected |
| Offline delivery | sealed mailbox, delivery after recipient returns, sender sees *delivered* |
| Group chat | multi-hop propagation without a server, duplicates/replays dropped, spam rate-limited, history sync, impersonation rejected |
| User groups | signed records cannot be edited or hijacked, discovery across hops, join/leave, history sync, private rooms unreadable by forwarders and non-members, only the owner can close, limits |
| Interruption | reconnect after connection loss; banned peer cannot reconnect |
| NAT | peer behind NAT reached through a relay with end-to-end encryption |
| API / UI | token and Host checks, UI served with strict CSP, no path traversal, local API end to end |
| Android project | manifest permissions, no cleartext except 127.0.0.1, Java <-> Python entry points exist |

The screens were also driven in headless Chromium (identity setup, username change, connect, private chat with live
incoming message, group chat, profile, settings, security) against two live engines.

**What these tests cannot prove:** behaviour on real phones, real mobile-carrier NAT, battery restrictions, or the
Android build itself.

## Two physical phones on different networks
Needs the APK on both phones and one public peer (`docs/BOOTSTRAP_NODE.md`).

1. Phone A on Wi-Fi, phone B on mobile data (Wi-Fi off). Install, open, create identities with different usernames.
2. On both: More -> Network status -> add the public peer's `gcp2p://...` address -> Save & connect.
3. Wait up to a minute. Both: Online users -> Refresh discovery. Expect the other phone listed as *Online*.
4. A opens B, sends "test 1". Expect status to go *waiting* -> *delivered* on A, a notification (app in background) or
   the message live (app open) on B.
5. Group: both open Group, send a line each. Expect both to appear on both phones.
6. Offline queue: on B enable airplane mode. A sends "while you were away". Expect *waiting* or *stored for delivery*.
   Turn airplane mode off on B, wait a minute, expect the message on B and *delivered* on A.
7. Reconnect: toggle B between Wi-Fi and mobile data; within about a minute Network status should show connections again.
8. Restart: force-stop and reopen B. Same peer ID, history still there.
9. Duplicate prevention: the same message must never appear twice in either chat.
10. Record anything that fails: the screen, Network status values and what you did.

## Media tests

`tests/test_media.py` (8 tests): type sniffing, encrypted storage, view-once consumption on both phones, chunked video download on tap,
rejection of disguised/oversize files, offer validation, third parties cannot pull, tampered data is discarded. A browser end-to-end
script (preview sheet, view-once viewer, "Opened" state, video download) was run with headless Chromium.
