"""Photos and videos in private chats, optionally "view once".

How it works (no server stores anything):
  1. The sender picks a file.  The phone keeps it encrypted at rest and makes a random 256-bit *file key*.
  2. An **offer** (type, size, SHA-256, view-once flag, caption, file key) is sent as an ordinary end-to-end encrypted
     private message, so it gets the same delivery, retry and offline-mailbox handling as text.
  3. When both phones are online, the receiver **pulls** the file from the sender in 128 KiB chunks over the already
     authenticated, encrypted peer link.  Every chunk is also encrypted with the file key, so a relay carrying the traffic
     sees only ciphertext.  The receiver checks size, SHA-256 and the file's real type, then stores it encrypted at rest.
  4. The receiver sends back a small acknowledgement ("got it", later "opened") as another private message.
  5. View once: the receiver's engine hands the bytes out ONE time, deletes the stored file, and tells the sender.
     The sender's copy is deleted as soon as the receiver has it.

Honest limits: the sender's phone must be online for the receiver to fetch the file (there is no storage node for big
files); "view once" cannot stop someone photographing the screen or a modified app from saving the bytes.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import re
import time
from collections import OrderedDict

from ..encryption import crypto
from ..networking.ratelimit import KeyedLimiter

CHUNK = 128 * 1024
MAX_IMAGE = 6 * 1024 * 1024
MAX_VIDEO = 25 * 1024 * 1024
OFFER_TTL = 7 * 86400
AUTO_MAX = MAX_IMAGE                 # images up to this size are fetched automatically; videos wait for a tap
AUTO_PER_HOUR = 60 * 1024 * 1024     # per sender, bounds what a stranger can make this phone download
STORE_LIMIT = 1024 * 1024 * 1024     # total media kept on the phone
MAX_CAPTION = 200
ALLOWED = {"image/jpeg", "image/png", "image/webp", "image/gif", "video/mp4", "video/webm", "video/3gpp", "video/quicktime"}
_HEX64 = re.compile(r"^[0-9a-f]{64}$")


class MediaError(Exception):
    pass


def sniff(data: bytes) -> str | None:
    """The real type from the file's first bytes (never trust the name or the declared type)."""
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data[:4] == b"\x1a\x45\xdf\xa3":
        return "video/webm"
    if data[4:8] == b"ftyp":
        brand = data[8:12]
        return "video/quicktime" if brand == b"qt  " else "video/3gpp" if brand[:3] == b"3gp" else "video/mp4"
    return None


def kind_of(mime: str) -> str:
    return "image" if mime.startswith("image/") else "video"


def limit_for(kind: str) -> int:
    return MAX_IMAGE if kind == "image" else MAX_VIDEO


def label(mid: str, i: int) -> bytes:
    return f"gcp2p-media|{mid}|{i}".encode()


def describe(kind: str, once: bool) -> str:
    return ("Photo" if kind == "image" else "Video") + (" (view once)" if once else "")


class MediaService:
    def __init__(self, node):
        self.node = node
        self.get_limiter = KeyedLimiter(rate=40.0, burst=80, clock=node.now)
        self._active: set[str] = set()
        self._next_try: dict[str, float] = {}
        self._cache: OrderedDict[str, bytes] = OrderedDict()
        node.handlers["media_get"] = self.on_media_get

    # ------------------------------------------------------------------ storage helpers
    def _need_store(self):
        if not getattr(self.node, "media_dir", None) or not getattr(self.node, "storage_key", None):
            raise MediaError("Media storage is not available on this node.")

    def _path(self, mid: str) -> str:
        return os.path.join(self.node.media_dir, mid + ".bin")

    def _save(self, mid: str, data: bytes) -> None:
        self._need_store()
        os.makedirs(self.node.media_dir, mode=0o700, exist_ok=True)
        tmp = self._path(mid) + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(crypto.wrap(self.node.storage_key, data, b"gcp2p-media-file|" + mid.encode()))
        os.replace(tmp, self._path(mid))

    def _load(self, mid: str) -> bytes:
        self._need_store()
        try:
            blob = open(self._path(mid), "rb").read()
            return crypto.unwrap(self.node.storage_key, blob, b"gcp2p-media-file|" + mid.encode())
        except (OSError, crypto.CryptoError) as exc:
            raise MediaError("The file is no longer available.") from exc

    def _delete(self, mid: str) -> None:
        self._cache.pop(mid, None)
        try:
            os.remove(self._path(mid))
        except OSError:
            pass

    def _fk(self, row: dict) -> bytes:
        return crypto.unwrap(self.node.storage_key, bytes(row["fk"]), b"gcp2p-media-key|" + row["id"].encode())

    def _stored_bytes(self) -> int:
        try:
            return sum(e.stat().st_size for e in os.scandir(self.node.media_dir) if e.is_file())
        except OSError:
            return 0

    def _emit(self, row: dict) -> None:
        self.node.emit("dm", {"peer": row["peer"], "id": row["id"]})

    # ------------------------------------------------------------------ views for the UI
    def info(self, mid: str) -> dict | None:
        r = self.node.db.media_get(mid)
        if r is None:
            return None
        state = r["state"]
        if state == "downloading" and mid not in self._active:
            state = "offered"
        return {"id": mid, "kind": r["kind"], "mime": r["mime"], "size": r["size"], "once": bool(r["once"]), "caption": r["caption"],
                "state": state, "viewed": bool(r["viewed"]), "dir": r["dir"], "note": r["note"],
                "auto": r["dir"] == "in" and self._auto_ok(r)}

    # ------------------------------------------------------------------ sending
    async def send(self, to: str, data: bytes, declared_mime: str = "", once: bool = False, caption: str = "") -> dict:
        self._need_store()
        if not crypto.valid_peer_id(to) or to == self.node.id:
            raise MediaError("Invalid recipient.")
        mime = sniff(data[:64])
        if mime is None or mime not in ALLOWED:
            raise MediaError("Only photos (JPEG, PNG, WebP, GIF) and videos (MP4, WebM, 3GP, MOV) can be sent.")
        if declared_mime and kind_of(declared_mime) != kind_of(mime):
            raise MediaError("The file does not match its type.")
        kind = kind_of(mime)
        if not data or len(data) > limit_for(kind):
            raise MediaError(f"{'Photos' if kind == 'image' else 'Videos'} can be at most {limit_for(kind) // (1024 * 1024)} MB.")
        caption = " ".join((caption or "").split())[:MAX_CAPTION]
        if not caption.isprintable() or "<" in caption or ">" in caption:
            raise MediaError("The caption has characters that are not allowed.")
        if self._stored_bytes() + len(data) > STORE_LIMIT:
            raise MediaError("Not enough space for media in the app. Delete old chats first.")
        mid = os.urandom(16).hex()
        fk = os.urandom(32)
        sha = hashlib.sha256(data).hexdigest()
        chunks = math.ceil(len(data) / CHUNK)
        self._save(mid, data)
        now = self.node.now()
        wfk = crypto.wrap(self.node.storage_key, fk, b"gcp2p-media-key|" + mid.encode())
        self.node.db.media_put(mid, to, "out", kind, mime, len(data), sha, once, caption, chunks, wfk, "offered", now)
        offer = {"v": 1, "k": kind, "m": mime, "s": len(data), "h": sha, "o": bool(once), "c": caption, "n": chunks, "fk": crypto.b64e(fk)}
        self.node.db.dm_insert(mid, to, "out", json.dumps(offer, separators=(",", ":")), now, "queued", kind="media")
        self.node.emit("dm", {"peer": to, "id": mid})
        asyncio.ensure_future(self.node.dm.attempt(mid))
        return {"id": mid, "status": "queued", "ts": now}

    async def on_media_get(self, conn, msg) -> dict:
        """The receiver pulls encrypted chunks.  Only the intended recipient can."""
        if not self.get_limiter.allow(conn.peer_id):
            return {"ok": False, "err": "rate limited"}
        mid, i = msg.get("id"), msg.get("i")
        row = self.node.db.media_get(mid) if isinstance(mid, str) and len(mid) == 32 else None
        if (row is None or row["dir"] != "out" or row["peer"] != conn.peer_id or row["state"] not in ("offered", "delivered", "opened")
                or not isinstance(i, int) or isinstance(i, bool) or not (0 <= i < row["chunks"])):
            return {"ok": False, "err": "not available"}
        if row["once"] and row["state"] != "offered":
            return {"ok": False, "err": "not available"}            # a view-once file is served until it has been received
        try:
            if mid not in self._cache:
                self._cache[mid] = self._load(mid)
                while len(self._cache) > 2:
                    self._cache.popitem(last=False)
            plain = self._cache[mid][i * CHUNK:(i + 1) * CHUNK]
            return {"ok": True, "c": crypto.b64e(crypto.wrap(self._fk(row), plain, label(mid, i)))}
        except (MediaError, crypto.CryptoError):
            return {"ok": False, "err": "not available"}

    # ------------------------------------------------------------------ receiving an offer
    def on_offer(self, sender: str, mid: str, body: str, ts: float) -> bool:
        """Validate an incoming offer and remember it.  False = reject (nothing stored)."""
        try:
            o = json.loads(body)
            kind, mime, size, sha, once, cap, n, fk = o["k"], o["m"], o["s"], o["h"], o["o"], o["c"], o["n"], crypto.b64d(o["fk"])
            if (o.get("v") != 1 or kind not in ("image", "video") or mime not in ALLOWED or kind_of(mime) != kind
                    or not isinstance(size, int) or isinstance(size, bool) or not (0 < size <= limit_for(kind))
                    or not isinstance(sha, str) or not _HEX64.match(sha) or not isinstance(once, bool)
                    or not isinstance(cap, str) or len(cap) > MAX_CAPTION or not cap.isprintable() or "<" in cap or ">" in cap
                    or n != math.ceil(size / CHUNK) or len(fk) != 32):
                return False
        except (ValueError, KeyError, TypeError, crypto.CryptoError):
            return False
        pending = len(self.node.db.media_list("peer=? AND dir='in' AND state='offered'", (sender,)))
        if pending >= 30:
            return False                                             # one sender cannot pile up unlimited offers
        wfk = crypto.wrap(self.node.storage_key, fk, b"gcp2p-media-key|" + mid.encode()) if getattr(self.node, "storage_key", None) else b""
        if not wfk:
            return False
        self.node.db.media_put(mid, sender, "in", kind, mime, size, sha, once, cap, n, wfk, "offered", ts)
        row = self.node.db.media_get(mid)
        if self._auto_ok(row):
            self.node.spawn(self.download(mid))
        return True

    def _auto_ok(self, row: dict) -> bool:
        return (row["kind"] == "image" and row["size"] <= AUTO_MAX
                and self.node.db.media_bytes_from(row["peer"], self.node.now() - 3600) <= AUTO_PER_HOUR)

    # ------------------------------------------------------------------ downloading
    async def download(self, mid: str) -> dict:
        row = self.node.db.media_get(mid)
        if row is None or row["dir"] != "in":
            raise MediaError("Unknown media.")
        if row["state"] in ("ready", "opened"):
            return self.info(mid)
        if row["state"] == "expired":
            raise MediaError("This file has expired.")
        if mid in self._active:
            return self.info(mid)
        if self._stored_bytes() + row["size"] > STORE_LIMIT:
            self.node.db.media_set(mid, note="Not enough space in the app.")
            raise MediaError("Not enough space for media in the app.")
        self._active.add(mid)
        self.node.db.media_set(mid, state="downloading", note="")
        self._emit(row)
        err = ""
        try:
            fk = self._fk(row)
            peer = self.node.db.get_peer(row["peer"]) or {}
            conn = await self.node.get_conn(row["peer"], peer.get("addrs") or [])
            if conn is None:
                raise MediaError("The sender is not reachable right now. It will be tried again.")
            parts = []
            for i in range(row["chunks"]):
                res = await conn.request({"t": "media_get", "id": mid, "i": i}, timeout=25)
                if not res.get("ok"):
                    raise MediaError("The sender no longer has this file.")
                parts.append(crypto.unwrap(fk, crypto.b64d(res["c"]), label(mid, i)))
            data = b"".join(parts)
            if len(data) != row["size"] or hashlib.sha256(data).hexdigest() != row["sha"] or sniff(data[:64]) != row["mime"]:
                raise MediaError("The file arrived damaged and was discarded.")
            self._save(mid, data)
            self.node.db.media_set(mid, state="ready", note="")
            self._emit(row)
            self._send_ack(row["peer"], mid, "got")
        except (crypto.CryptoError, KeyError, TypeError, ValueError):
            err = "The file arrived damaged and was discarded."
        except MediaError as exc:
            err = str(exc)
        except Exception as exc:
            err = f"Download failed ({type(exc).__name__})."
        finally:
            self._active.discard(mid)
        if err:
            self._next_try[mid] = self.node.now() + 60
            self.node.db.media_set(mid, state="offered", note=err)
            self._emit(row)
            raise MediaError(err)
        return self.info(mid)

    async def retry_pending(self) -> None:
        now = self.node.now()
        for r in self.node.db.media_list("dir='in' AND state='offered'")[:20]:
            if (now - r["ts"] < OFFER_TTL and r["id"] not in self._active and self._next_try.get(r["id"], 0) <= now and self._auto_ok(r)):
                self._next_try[r["id"]] = now + 60
                self.node.spawn(self._quiet_download(r["id"]))
                break                                                # one at a time per tick

    async def _quiet_download(self, mid: str) -> None:
        try:
            await self.download(mid)
        except MediaError:
            pass

    # ------------------------------------------------------------------ opening (view once lives here)
    def open(self, mid: str) -> tuple[str, bytes]:
        row = self.node.db.media_get(mid)
        if row is None:
            raise MediaError("Unknown media.")
        if row["dir"] == "out":
            if row["once"]:
                raise MediaError("A view-once file cannot be opened again on the phone that sent it.")
            return row["mime"], self._load(mid)
        if row["state"] == "opened" or (row["once"] and row["viewed"]):
            raise MediaError("This was view-once and has already been opened.")
        if row["state"] != "ready":
            raise MediaError("Download the file first.")
        data = self._load(mid)
        first = not row["viewed"]
        if row["once"]:
            self.node.db.media_set(mid, state="opened", viewed=1)    # mark first, so a crash can never allow a second view
            self._delete(mid)
        else:
            self.node.db.media_set(mid, viewed=1)
        if first:
            self._send_ack(row["peer"], mid, "viewed")
        self._emit(row)
        return row["mime"], data

    # ------------------------------------------------------------------ acknowledgements (travel as private messages)
    def _send_ack(self, to: str, mid: str, what: str) -> None:
        rid = os.urandom(16).hex()
        self.node.db.dm_insert(rid, to, "out", json.dumps({"id": mid, "s": what}), self.node.now(), "queued", kind="mack")
        asyncio.ensure_future(self.node.dm.attempt(rid))

    def on_ack(self, sender: str, body: str) -> None:
        try:
            a = json.loads(body)
            mid, what = a["id"], a["s"]
        except (ValueError, KeyError, TypeError):
            return
        row = self.node.db.media_get(mid) if isinstance(mid, str) else None
        if row is None or row["dir"] != "out" or row["peer"] != sender or what not in ("got", "viewed"):
            return
        if what == "got" and row["state"] == "offered":
            self.node.db.media_set(mid, state="delivered")
        elif what == "viewed":
            self.node.db.media_set(mid, state="opened", viewed=1)
        if row["once"]:
            self._delete(mid)                                        # the receiver has it; the sender keeps no copy
        self.node.emit("dm", {"peer": sender, "id": mid})

    # ------------------------------------------------------------------ housekeeping
    def expire(self) -> None:
        now = self.node.now()
        for r in self.node.db.media_list("state='offered' AND ts<?", (now - OFFER_TTL,)):
            self._delete(r["id"])
            self.node.db.media_set(r["id"], state="expired", note="Not downloaded in time.")
            self._emit(r)
