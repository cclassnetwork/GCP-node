"""Private (direct) messaging with end-to-end encryption and offline delivery.

Delivery strategy, in order:
  1. Direct (or relayed) authenticated connection -> recipient ACKs  => "delivered"
  2. Recipient unreachable -> the *encrypted* envelope is stored on the DHT
     peers closest to the recipient ("mailbox")                      => "sent"
     The recipient fetches it when it comes online and returns a signed
     receipt                                                         => "delivered"
  3. Retry with exponential back-off until delivered or 72 h elapse    => "failed"
Relays and mailbox peers only ever see ciphertext and the recipient's ID.
"""
from __future__ import annotations

import asyncio
import json
import os
import time

from ..encryption import crypto
from ..identity.identity import USERNAME_RE
from ..networking.ratelimit import KeyedLimiter

MAX_BODY = 4000
MAX_ENV_BYTES = 64 * 1024
MAILBOX_TTL = 72 * 3600
MAILBOX_PER_RECIPIENT = 100
MAILBOX_TOTAL = 5000
MAX_AGE_OUT = 72 * 3600
ACCEPT_PAST = 7 * 86400
ACCEPT_FUTURE = 600


class DmError(Exception):
    pass


class DmService:
    def __init__(self, node):
        self.node = node
        self.put_limiter = KeyedLimiter(rate=0.5, burst=20, clock=node.now)
        self.dm_limiter = KeyedLimiter(rate=2.0, burst=30, clock=node.now)
        self._fetch_lock = asyncio.Lock()
        h = node.handlers
        h["dm"] = self.on_dm
        h["mbox_put"] = self.on_mbox_put
        h["mbox_get"] = self.on_mbox_get
        h["mbox_del"] = self.on_mbox_del

    # ------------------------------------------------------------------ sending
    async def send(self, to: str, text: str) -> dict:
        if not crypto.valid_peer_id(to) or to == self.node.id:
            raise DmError("Invalid recipient.")
        if not isinstance(text, str) or not text.strip():
            raise DmError("Message is empty.")
        if len(text) > MAX_BODY:
            raise DmError("Message is too long.")
        mid = os.urandom(16).hex()
        ts = self.node.now()
        self.node.db.dm_insert(mid, to, "out", text, ts, "queued", kind="msg")
        self.node.emit("dm", {"peer": to, "id": mid})
        asyncio.ensure_future(self.attempt(mid))
        return {"id": mid, "status": "queued", "ts": ts}

    def _build(self, to: str, kind: str, body: str, mid: str, ts: float, xpk: bytes) -> dict:
        inner = {
            "id": mid, "kind": kind, "from": self.node.id, "to": to, "ts": round(ts, 3), "body": body,
            "pub": crypto.b64e(self.node.identity.pub), "xpk": crypto.b64e(self.node.identity.xpub),
            "username": self.node.username,
        }
        inner["sig"] = crypto.b64e(self.node.identity.sign(b"gcp2p-dm|" + crypto.canonical(inner)))
        aad = f"{to}|{mid}".encode()
        env = crypto.seal(xpk, json.dumps(inner, separators=(",", ":")).encode(), aad)
        env.update({"v": 1, "id": mid, "to": to})
        return env

    async def _recipient_keys(self, to: str):
        info = self.node.db.get_peer(to)
        if info and info.get("xpk"):
            return info
        rec = await self.node.dht.find_presence(to)
        if rec:
            try:
                self.node.presence.ingest(rec)
            except Exception:
                return None
            return self.node.db.get_peer(to)
        return None

    async def attempt(self, mid: str) -> None:
        row = self.node.db.dm_get(mid)
        if not row or row["status"] not in ("queued", "sent"):
            return
        now = self.node.now()
        attempts = row["attempts"] + 1
        to = row["peer"]
        if now - row["ts"] > MAX_AGE_OUT:
            self.node.db.dm_update(mid, status="failed", note="Could not be delivered within 72 hours.")
            self.node.emit("dm", {"peer": to, "id": mid})
            return
        status, note = row["status"], ""
        try:
            info = await self._recipient_keys(to)
            if not info:
                note = "Recipient's key not found yet."
                raise DmError(note)
            env = self._build(to, row["kind"], row["body"], mid, row["ts"], bytes(info["xpk"]))
            delivered = False
            conn = await self.node.get_conn(to, info.get("addrs") or [])
            if conn is not None:
                try:
                    res = await conn.request({"t": "dm", "env": env}, timeout=8)
                    delivered = bool(res.get("ok"))
                except Exception:
                    delivered = False
            if delivered:
                status, note = "delivered", ""
            else:
                stored = await self.mailbox_put(to, env)
                if stored:
                    status, note = "sent", f"Stored encrypted on {stored} peer(s); waiting for recipient."
                else:
                    note = "Recipient offline and no relay peer available."
        except DmError:
            pass
        except Exception as exc:  # never let one message kill the outbox
            note = f"error: {type(exc).__name__}"
        delay = min(300, 5 * (2 ** min(attempts - 1, 6))) if status == "queued" else 90
        if status == "delivered":
            delay = 0
        self.node.db.dm_update(mid, status=status, attempts=attempts, next_try=now + delay, note=note)
        if status != row["status"] or status == "delivered":
            self.node.emit("dm", {"peer": to, "id": mid})

    async def pump_outbox(self) -> None:
        for row in self.node.db.dm_due(self.node.now(), limit=10):
            await self.attempt(row["id"])

    # ---------------------------------------------------------------- receiving
    def ingest(self, env, via: str) -> tuple[bool, str]:
        """Decrypt + verify an envelope.  Returns (accepted_or_duplicate, reason)."""
        try:
            if not isinstance(env, dict) or env.get("v") != 1:
                return False, "bad envelope"
            mid, to = env.get("id"), env.get("to")
            if to != self.node.id or not isinstance(mid, str) or len(mid) != 32:
                return False, "not for me"
            if len(json.dumps(env)) > MAX_ENV_BYTES:
                return False, "too large"
            plain = crypto.unseal(self.node.identity.x_sk, self.node.identity.xpub, env, f"{to}|{mid}".encode())
            inner = json.loads(plain.decode("utf-8"))
            if not isinstance(inner, dict):
                return False, "bad inner"
            pub = crypto.b64d(inner["pub"])
            xpk = crypto.b64d(inner["xpk"])
            sig = crypto.b64d(inner.pop("sig"))
            if len(pub) != 32 or len(xpk) != 32:
                return False, "bad keys"
            if inner["from"] != crypto.peer_id_from_pub(pub) or inner["to"] != self.node.id or inner["id"] != mid:
                return False, "identity mismatch"
            if not crypto.verify(pub, sig, b"gcp2p-dm|" + crypto.canonical({**inner})):
                return False, "bad signature"
            body, kind, ts = inner["body"], inner["kind"], inner["ts"]
            username = inner.get("username", "")
            if kind not in ("msg", "rcpt", "media", "mack") or not isinstance(body, str) or len(body) > MAX_BODY:
                return False, "bad content"
            if not isinstance(ts, (int, float)) or isinstance(ts, bool):
                return False, "bad time"
            now = self.node.now()
            if ts > now + ACCEPT_FUTURE or now - ts > ACCEPT_PAST:
                return False, "outside time window"
            if not isinstance(username, str) or not USERNAME_RE.match(username):
                username = ""
        except (crypto.CryptoError, KeyError, ValueError, TypeError):
            return False, "invalid"
        sender = inner["from"]
        self.node.db.upsert_peer(sender, pub=pub, xpk=xpk, username=username or None, seen=now)
        if kind == "rcpt":
            row = self.node.db.dm_get(body)
            if row and row["dir"] == "out" and row["peer"] == sender and row["status"] != "delivered":
                self.node.db.dm_update(body, status="delivered", note="")
                self.node.emit("dm", {"peer": sender, "id": body})
            return True, "receipt"
        if kind == "mack":
            self.node.media.on_ack(sender, body)
            return True, "receipt"
        if self.node.db.dm_exists(mid):
            return True, "duplicate"
        if kind == "media":
            if not self.node.media.on_offer(sender, mid, body, ts):
                return False, "bad content"
            self.node.db.dm_insert(mid, sender, "in", body, ts, "received", kind="media", read=0)
            self.node.emit("dm", {"peer": sender, "id": mid})
            try:
                o = json.loads(body)
                text = ("\U0001F4F7 Photo" if o["k"] == "image" else "\U0001F3AC Video") + (" (view once)" if o["o"] else "")
            except (ValueError, KeyError):
                text = "Media"
            self.node.notify_message(sender, username or sender[-6:], text, private=True)
            if via == "mailbox":
                asyncio.ensure_future(self._send_receipt(sender, mid))
            return True, "new"
        self.node.db.dm_insert(mid, sender, "in", body, ts, "received", read=0)
        self.node.emit("dm", {"peer": sender, "id": mid})
        self.node.notify_message(sender, username or sender[-6:], body, private=True)
        if via == "mailbox":
            asyncio.ensure_future(self._send_receipt(sender, mid))
        return True, "new"

    async def _send_receipt(self, to: str, mid: str) -> None:
        rid = os.urandom(16).hex()
        self.node.db.dm_insert(rid, to, "out", mid, self.node.now(), "queued", kind="rcpt")
        await self.attempt(rid)

    async def on_dm(self, conn, msg) -> dict:
        if not self.dm_limiter.allow(conn.peer_id):
            return {"ok": False, "err": "rate limited"}
        ok, reason = self.ingest(msg.get("env"), "direct")
        if not ok and reason in ("invalid", "bad signature", "identity mismatch", "bad envelope"):
            self.node.penalize(conn, 15, f"bad dm: {reason}")
        return {"ok": ok}

    # ------------------------------------------------------------------ mailbox
    async def mailbox_put(self, to: str, env: dict) -> int:
        if not self.node.store_forward_available():
            return 0
        target = crypto.key_id("mbox", to)
        closest, _ = await self.node.dht.lookup(target)
        count = 0
        for pid in self.node.dht.replica_set(closest, target):
            if pid == self.node.id:
                if self.node.store_forward and self._store(to, env, self.node.id):
                    count += 1
                continue
            conn = self.node.conns.get(pid)
            if conn is None:
                conn = await self.node.get_conn(pid, [])
            if conn is None:
                continue
            try:
                r = await conn.request({"t": "mbox_put", "to": to, "env": env}, timeout=8)
                count += 1 if r.get("ok") else 0
            except Exception:
                continue
        return count

    def _store(self, to: str, env: dict, putter: str) -> bool:
        db = self.node.db
        raw = json.dumps(env)
        if len(raw) > MAX_ENV_BYTES or db.mbox_count() >= MAILBOX_TOTAL or db.mbox_count(to) >= MAILBOX_PER_RECIPIENT:
            return False
        db.mbox_put(env["id"], to, raw, self.node.now() + MAILBOX_TTL, putter, len(raw))
        return True

    async def on_mbox_put(self, conn, msg) -> dict:
        if not self.node.store_forward:
            return {"ok": False, "err": "not a mailbox node"}
        to, env = msg.get("to"), msg.get("env")
        if not crypto.valid_peer_id(to) or not isinstance(env, dict) or env.get("to") != to \
                or not isinstance(env.get("id"), str) or len(env["id"]) != 32:
            self.node.penalize(conn, 10, "bad mbox_put")
            return {"ok": False, "err": "bad request"}
        if not self.put_limiter.allow(conn.peer_id):
            return {"ok": False, "err": "rate limited"}
        return {"ok": self._store(to, env, conn.peer_id)}

    async def on_mbox_get(self, conn, msg) -> dict:
        # Authenticated channel: a peer can only read its own mailbox.
        rows = self.node.db.mbox_get(conn.peer_id, self.node.now())
        out = []
        for r in rows:
            try:
                out.append({"id": r["id"], "env": json.loads(r["env"])})
            except ValueError:
                continue
        return {"items": out}

    async def on_mbox_del(self, conn, msg) -> dict:
        ids = [i for i in (msg.get("ids") or []) if isinstance(i, str)][:100]
        self.node.db.mbox_delete(conn.peer_id, ids)
        return {"ok": True}

    async def fetch_mailbox(self) -> int:
        """Collect messages other peers stored for us while we were offline."""
        if self._fetch_lock.locked():
            return 0
        async with self._fetch_lock:
            return await self._fetch_mailbox()

    async def _fetch_mailbox(self) -> int:
        got = 0
        target = crypto.key_id("mbox", self.node.id)
        closest, _ = await self.node.dht.lookup(target)
        holders = [p for p in self.node.dht.replica_set(closest, target)]
        # also ask all connected peers: cheap, and covers table inconsistencies
        holders += [p for p in list(self.node.conns) if p not in holders][:6]
        for pid in holders:
            if pid == self.node.id:
                items = self.node.db.mbox_get(self.node.id, self.node.now())
                items = [{"id": r["id"], "env": json.loads(r["env"])} for r in items]
                conn = None
            else:
                conn = self.node.conns.get(pid) or await self.node.get_conn(pid, [])
                if conn is None:
                    continue
                try:
                    items = (await conn.request({"t": "mbox_get"}, timeout=8)).get("items") or []
                except Exception:
                    continue
            done = []
            for it in items[:50]:
                try:
                    ok, reason = self.ingest(it["env"], "mailbox")
                except (KeyError, TypeError):
                    continue
                if ok:
                    done.append(it["id"])
                    got += 1 if reason == "new" else 0
            if done:
                if conn is None:
                    self.node.db.mbox_delete(self.node.id, done)
                else:
                    try:
                        await conn.request({"t": "mbox_del", "ids": done}, timeout=6)
                    except Exception:
                        pass
        return got
