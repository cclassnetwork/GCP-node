"""User-created group rooms.

Anyone can create a room.  There are two kinds:

public   Announced by a signed record that spreads by gossip, so every user can find it under "Discover" and join with a tap.
         Messages are signed but NOT encrypted (like the global group): every member and forwarding peer can read them.
private  Not announced anywhere.  Members share an invite code that contains the room key; messages are encrypted with
         ChaCha20-Poly1305 under that key, so forwarding peers only see ciphertext.  Anyone holding the code can read and join.

"Joining" is a local subscription: there is no server that keeps a member list.  Every peer forwards valid room messages
(so small rooms still reach their members through the mesh) but stores only the rooms it has joined.
Moderation is limited: the owner can close a public room (a signed tombstone); there is no per-member ban yet.
"""
from __future__ import annotations

import base64
import os
import re

from ..encryption import crypto
from ..networking.ratelimit import KeyedLimiter

GID_RE = re.compile(r"^gr[a-z2-7]{20}$")
MAX_OWNED = 5
MAX_JOINED = 30
MAX_NAME, MIN_NAME, MAX_DESC = 40, 3, 120
INVITE_PREFIX = "gcg1"


class RoomError(Exception):
    pass


def clean_text(s, lo: int, hi: int, what: str) -> str:
    if not isinstance(s, str):
        raise RoomError(f"{what} must be text.")
    s = " ".join(s.split())            # collapse whitespace, no newlines
    if not (lo <= len(s) <= hi) or not s.isprintable() or any(c in s for c in "<>"):
        raise RoomError(f"{what} must be {lo}-{hi} characters (no < or >)." if lo else f"{what} is at most {hi} characters.")
    return s


def new_gid(pub: bytes, name: str, nonce: str) -> str:
    h = crypto.sha256(pub + name.encode() + nonce.encode())[:12]
    return "gr" + base64.b32encode(h).decode().lower().rstrip("=")


def make_record(identity, name: str, desc: str, ts: float, nonce: str | None = None, closed: bool = False) -> dict:
    nonce = nonce or os.urandom(6).hex()
    rec = {"gid": new_gid(identity.pub, name, nonce), "name": name, "desc": desc, "nonce": nonce, "owner": identity.peer_id,
           "pub": crypto.b64e(identity.pub), "ts": round(ts, 3), "closed": bool(closed)}
    rec["sig"] = crypto.b64e(identity.sign(b"gcp2p-room|" + crypto.canonical(rec)))
    return rec


def verify_record(rec, now: float) -> dict:
    if not isinstance(rec, dict) or set(rec) != {"gid", "name", "desc", "nonce", "owner", "pub", "ts", "closed", "sig"}:
        raise RoomError("malformed")
    try:
        pub, sig = crypto.b64d(rec["pub"]), crypto.b64d(rec["sig"])
        name = clean_text(rec["name"], MIN_NAME, MAX_NAME, "name")
        desc = clean_text(rec["desc"], 0, MAX_DESC, "description") if rec["desc"] else ""
    except (crypto.CryptoError, RoomError) as exc:
        raise RoomError("bad fields") from exc
    if name != rec["name"] or desc != rec["desc"]:
        raise RoomError("not normalised")
    if not isinstance(rec["nonce"], str) or not re.fullmatch(r"[0-9a-f]{12}", rec["nonce"]) or not isinstance(rec["closed"], bool):
        raise RoomError("bad nonce/closed")
    if len(pub) != 32 or rec["owner"] != crypto.peer_id_from_pub(pub):
        raise RoomError("owner mismatch")
    if rec["gid"] != new_gid(pub, rec["name"], rec["nonce"]) or not GID_RE.match(rec["gid"]):
        raise RoomError("room id does not match")
    ts = rec["ts"]
    if not isinstance(ts, (int, float)) or isinstance(ts, bool) or ts > now + 300:
        raise RoomError("bad ts")
    body = {k: v for k, v in rec.items() if k != "sig"}
    if not crypto.verify(pub, sig, b"gcp2p-room|" + crypto.canonical(body)):
        raise RoomError("bad signature")
    return rec


# ---- private rooms: invite code and message encryption ---------------------------------------------------------
def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _unb64u(s: str) -> bytes:
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", s):
        raise ValueError("bad base64")
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def make_invite(gid: str, key: bytes, name: str) -> str:
    return f"{INVITE_PREFIX}:{gid}:{_b64u(key)}:{_b64u(name.encode())}"


def parse_invite(code: str):
    try:
        pre, gid, key, name = (code or "").strip().split(":")
        key, name = _unb64u(key), _unb64u(name).decode()
        if pre != INVITE_PREFIX or not GID_RE.match(gid) or len(key) != 32:
            raise ValueError
        return gid, key, clean_text(name, MIN_NAME, MAX_NAME, "name")
    except (ValueError, RoomError, UnicodeDecodeError):
        raise RoomError("That invite code is not valid.") from None


def aad(room: str, peer: str, mid: str, ts: float) -> bytes:
    return f"gcp2p-room-msg|{room}|{peer}|{mid}|{ts}".encode()


class RoomService:
    def __init__(self, node):
        self.node = node
        self.limiter = KeyedLimiter(rate=0.05, burst=3, clock=node.now)       # room announcements per owner
        node.handlers["rooms_req"] = self.on_rooms_req

    # ---- queries ---------------------------------------------------------------------------------------------
    def get(self, gid: str) -> dict | None:
        return self.node.db.room_get(gid) if GID_RE.match(gid or "") else None

    def _owner_handle(self, owner: str) -> str:
        from ..identity.identity import handle
        if not owner:
            return ""
        if owner == self.node.id:
            name = self.node.username
        else:
            name = (self.node.db.get_peer(owner) or {}).get("username") or "owner"
        return handle(name, owner)

    def listing(self) -> list:
        out = []
        for r in self.node.db.room_list():
            if r["kind"] == "private" and not r["joined"]:
                continue
            out.append({"gid": r["gid"], "name": r["name"], "desc": r["descr"], "kind": r["kind"], "joined": bool(r["joined"]),
                        "mine": bool(r["mine"]), "closed": bool(r["closed"]), "last_ts": r["last_ts"], "created": r["ts"],
                        "owner": r["owner"], "owner_handle": self._owner_handle(r["owner"])})
        return out

    # ---- actions -----------------------------------------------------------------------------------------------
    async def create(self, name, desc, kind: str) -> dict:
        db = self.node.db
        name = clean_text(name, MIN_NAME, MAX_NAME, "Group name")
        desc = clean_text(desc or "", 0, MAX_DESC, "Description") if (desc or "").strip() else ""
        if kind not in ("public", "private"):
            raise RoomError("Choose public or private.")
        if sum(1 for r in db.room_list() if r["mine"] and not r["closed"]) >= MAX_OWNED:
            raise RoomError(f"You can own at most {MAX_OWNED} groups. Delete one first.")
        if sum(1 for r in db.room_list() if r["joined"]) >= MAX_JOINED:
            raise RoomError(f"You can be in at most {MAX_JOINED} groups. Leave one first.")
        now = self.node.now()
        if kind == "public":
            rec = make_record(self.node.identity, name, desc, now)
            import json
            db.room_put(rec["gid"], name, desc, self.node.id, "public", now, joined=1, mine=1, raw=json.dumps(rec, separators=(",", ":")))
            await self.node.broadcast({"t": "g", "k": "grec", "m": rec, "h": 0}, fanout=20)
            gid = rec["gid"]
        else:
            gid = "gr" + base64.b32encode(os.urandom(12)).decode().lower().rstrip("=")
            db.room_put(gid, name, desc, self.node.id, "private", now, key=os.urandom(32), joined=1, mine=1)
        self.node.emit("group", {"room": gid})
        return self.detail(gid)

    def detail(self, gid: str) -> dict:
        r = self.get(gid)
        if r is None:
            raise RoomError("Unknown group.")
        d = next((x for x in self.listing() if x["gid"] == gid), None)
        if d is None:
            raise RoomError("Unknown group.")
        if r["kind"] == "private" and r["joined"] and r["key"]:
            d["invite"] = make_invite(gid, bytes(r["key"]), r["name"])
        return d

    async def join(self, gid: str) -> dict:
        db = self.node.db
        r = self.get(gid)
        if r is None or r["kind"] != "public":
            raise RoomError("That group is not known to this phone yet. Refresh and try again, or use an invite code.")
        if r["closed"]:
            raise RoomError("The owner has closed this group.")
        if not r["joined"]:
            if sum(1 for x in db.room_list() if x["joined"]) >= MAX_JOINED:
                raise RoomError(f"You can be in at most {MAX_JOINED} groups. Leave one first.")
            db.room_set(gid, joined=1)
            self.node.spawn(self._catch_up())
        self.node.emit("group", {"room": gid})
        return self.detail(gid)

    async def join_invite(self, code: str) -> dict:
        gid, key, name = parse_invite(code)
        db = self.node.db
        cur = db.room_get(gid)
        if cur is None:
            if sum(1 for x in db.room_list() if x["joined"]) >= MAX_JOINED:
                raise RoomError(f"You can be in at most {MAX_JOINED} groups. Leave one first.")
            db.room_put(gid, name, "", "", "private", self.node.now(), key=key, joined=1)
        elif cur["kind"] == "public":
            raise RoomError("That code is not valid.")
        else:
            db.room_set(gid, key=key, joined=1)
        self.node.spawn(self._catch_up())
        self.node.emit("group", {"room": gid})
        return self.detail(gid)

    async def _catch_up(self) -> None:
        for c in [c for c in self.node.conns.values() if c.ready.is_set()][:4]:
            await self.node.group.sync_with(c)

    def leave(self, gid: str) -> None:
        r = self.get(gid)
        if r is None:
            raise RoomError("Unknown group.")
        db = self.node.db
        db.group_delete_room(gid)                                   # leaving removes the local history
        if r["kind"] == "private":
            db.room_delete(gid)                                     # and forgets the key
        else:
            db.room_set(gid, joined=0)
        self.node.emit("group", {"room": gid})

    async def close(self, gid: str) -> None:
        """Owner closes a public room: a signed tombstone tells everyone."""
        r = self.get(gid)
        if r is None or not r["mine"]:
            raise RoomError("Only the owner can close a group.")
        if r["kind"] == "private":
            return self.leave(gid)
        import json
        rec = make_record(self.node.identity, r["name"], r["descr"], self.node.now(), nonce=json.loads(r["raw"])["nonce"], closed=True)
        self.node.db.room_put(gid, r["name"], r["descr"], self.node.id, "public", rec["ts"], closed=1, raw=json.dumps(rec, separators=(",", ":")))
        self.node.db.group_delete_room(gid)
        self.node.db.room_set(gid, joined=0)
        await self.node.broadcast({"t": "g", "k": "grec", "m": rec, "h": 0}, fanout=20)
        self.node.emit("group", {"room": gid})

    # ---- gossip / sync ---------------------------------------------------------------------------------------
    async def on_gossip(self, conn, rec, hops: int) -> bool:
        try:
            rec = verify_record(rec, self.node.now())
        except RoomError:
            self.node.penalize(conn, 20, "invalid room record")
            return False
        return self.ingest(rec) and hops < 8

    def ingest(self, rec: dict) -> bool:
        import json
        db = self.node.db
        cur = db.room_get(rec["gid"])
        if cur and rec["ts"] <= cur["ts"] and not (rec["closed"] and not cur["closed"]):
            return False
        if cur and cur["kind"] == "private":
            return False
        if cur and cur["owner"] and cur["owner"] != rec["owner"]:
            return False
        if rec["owner"] != self.node.id and not self.limiter.allow(rec["owner"]):
            return False
        if cur is None:
            if rec["closed"]:
                return False                                        # never seen it: nothing to tombstone
        db.room_put(rec["gid"], rec["name"], rec["desc"], rec["owner"], "public", rec["ts"], closed=1 if rec["closed"] else 0,
                    raw=json.dumps(rec, separators=(",", ":")), joined=cur["joined"] if cur else 0, mine=cur["mine"] if cur else 0)
        if rec["closed"] and cur and cur["joined"] and not cur["mine"]:
            pass                                                    # stays readable locally; sending is refused (see GroupService)
        db.room_trim()
        self.node.emit("group", {"room": rec["gid"]})
        return True

    async def on_rooms_req(self, conn, msg) -> dict:
        return {"recs": self.node.db.room_public_raw(100)}

    async def sync_from(self, conn) -> None:
        try:
            res = await conn.request({"t": "rooms_req"}, timeout=8)
        except Exception:
            return
        for rec in (res.get("recs") or [])[:100]:
            try:
                self.ingest(verify_record(rec, self.node.now()))
            except RoomError:
                self.node.penalize(conn, 10, "invalid room record in sync")

    async def announce(self) -> None:
        """Owners keep their public rooms visible to newcomers."""
        for rec in [r for r in self.node.db.room_public_raw(100) if r["owner"] == self.node.id and not r["closed"]][:MAX_OWNED]:
            await self.node.broadcast({"t": "g", "k": "grec", "m": rec, "h": 0}, fanout=8)
