"""Decentralized global group chat.

Every message is signed by its author, carries a unique ID, and is spread
by gossip: each peer validates it, stores it, and forwards it to a bounded
random subset of its neighbours.  Peers also run anti-entropy sync (ask a
neighbour "which messages do I lack?") so temporary disconnections heal.
No peer is required to reach every device; the network is a mesh.
"""
from __future__ import annotations

import json
import os
from collections import OrderedDict

from ..encryption import crypto
from ..identity.identity import USERNAME_RE
from ..networking.ratelimit import KeyedLimiter
from .rooms import GID_RE, aad

ROOM = "global"
MAX_BODY = 1000
MAX_ENVELOPE_BODY = 2400     # private rooms carry base64 ciphertext of up to MAX_BODY characters
ACCEPT_WINDOW = 300          # live gossip must be within +/- 5 minutes
SYNC_WINDOW = 24 * 3600      # sync may deliver messages up to a day old
MAX_HOPS = 8
FANOUT = 8


class GroupError(Exception):
    pass


def make_message(identity, username: str, body: str, ts: float, room: str = ROOM) -> dict:
    m = {
        "id": os.urandom(16).hex(), "room": room, "peer": identity.peer_id,
        "pub": crypto.b64e(identity.pub), "username": username, "ts": round(ts, 3), "body": body,
    }
    m["sig"] = crypto.b64e(identity.sign(b"gcp2p-group|" + crypto.canonical(m)))
    return m


def verify_message(m, now: float, window: float = ACCEPT_WINDOW) -> dict:
    if not isinstance(m, dict) or set(m) != {"id", "room", "peer", "pub", "username", "ts", "body", "sig"}:
        raise GroupError("malformed")
    try:
        pub, sig = crypto.b64d(m["pub"]), crypto.b64d(m["sig"])
    except crypto.CryptoError as exc:
        raise GroupError("bad encoding") from exc
    if not isinstance(m["id"], str) or len(m["id"]) != 32 or not isinstance(m["room"], str) or not (m["room"] == ROOM or GID_RE.match(m["room"])):
        raise GroupError("bad id/room")
    if len(pub) != 32 or m["peer"] != crypto.peer_id_from_pub(pub):
        raise GroupError("identity mismatch")
    if not isinstance(m["username"], str) or not USERNAME_RE.match(m["username"]):
        raise GroupError("bad username")
    limit = MAX_BODY if m["room"] == ROOM else MAX_ENVELOPE_BODY    # members of public rooms re-check the 1000 limit
    if not isinstance(m["body"], str) or not m["body"].strip() or len(m["body"]) > limit:
        raise GroupError("bad body")
    ts = m["ts"]
    if not isinstance(ts, (int, float)) or isinstance(ts, bool):
        raise GroupError("bad ts")
    if ts > now + ACCEPT_WINDOW or now - ts > window:
        raise GroupError("outside time window")
    body = {k: v for k, v in m.items() if k != "sig"}
    if not crypto.verify(pub, sig, b"gcp2p-group|" + crypto.canonical(body)):
        raise GroupError("bad signature")
    return m


class GroupService:
    def __init__(self, node):
        self.node = node
        # per-author limit: 6 messages burst, then 1 every 2 seconds (shared by the global group and all rooms)
        self.author_limiter = KeyedLimiter(rate=0.5, burst=6, clock=node.now)
        self.seen: OrderedDict[str, None] = OrderedDict()       # ids forwarded for rooms I am not in
        node.handlers["sync_req"] = self.on_sync_req

    def _remember(self, mid: str) -> bool:
        """True if new."""
        if mid in self.seen:
            return False
        self.seen[mid] = None
        while len(self.seen) > 5000:
            self.seen.popitem(last=False)
        return True

    # ---- sending ---------------------------------------------------------------------------------------------
    async def send(self, body: str, room: str = ROOM) -> dict:
        if not isinstance(body, str) or not body.strip():
            raise GroupError("Message is empty.")
        body = body.strip()
        if len(body) > MAX_BODY:
            raise GroupError("Message is too long.")
        if not self.author_limiter.allow(self.node.id):
            raise GroupError("You are sending too fast. Wait a moment.")
        now = self.node.now()
        if room == ROOM:
            m = make_message(self.node.identity, self.node.username, body, now)
            display = None
        else:
            r = self.node.db.room_get(room)
            if r is None or not r["joined"]:
                raise GroupError("Join this group first.")
            if r["closed"]:
                raise GroupError("The owner has closed this group.")
            m = make_message(self.node.identity, self.node.username, body, now, room=room)
            display = None
            if r["kind"] == "private":
                m = self._seal(r, body, now)
                display = {"username": self.node.username, "body": body}
        self.node.db.group_insert(m, True, now, display)
        if room != ROOM:
            self.node.db.room_set(room, last_ts=m["ts"])
        self._remember(m["id"])
        self.node.emit("group", {"id": m["id"], "room": room})
        await self.node.broadcast({"t": "g", "k": "grp", "m": m, "h": 0}, fanout=FANOUT)
        return {"id": m["id"], "ts": m["ts"]}

    def _seal(self, r: dict, body: str, now: float) -> dict:
        """Private room: signed envelope whose body is ChaCha20-Poly1305 ciphertext under the room key."""
        ident = self.node.identity
        mid, ts = os.urandom(16).hex(), round(now, 3)
        plain = json.dumps({"u": self.node.username, "b": body}, ensure_ascii=False).encode()
        ct = crypto.wrap(bytes(r["key"]), plain, aad(r["gid"], ident.peer_id, mid, ts))
        m = {"id": mid, "room": r["gid"], "peer": ident.peer_id, "pub": crypto.b64e(ident.pub), "username": "member", "ts": ts,
             "body": crypto.b64e(ct)}
        m["sig"] = crypto.b64e(ident.sign(b"gcp2p-group|" + crypto.canonical(m)))
        return m

    def _open(self, r: dict, m: dict) -> dict:
        """Decrypt a private-room envelope -> {"username","body"}."""
        try:
            plain = crypto.unwrap(bytes(r["key"]), crypto.b64d(m["body"]), aad(m["room"], m["peer"], m["id"], m["ts"]))
            d = json.loads(plain.decode())
            u, b = d["u"], d["b"]
        except (crypto.CryptoError, ValueError, KeyError, TypeError, UnicodeDecodeError) as exc:
            raise GroupError("cannot decrypt") from exc
        if not isinstance(u, str) or not USERNAME_RE.match(u) or not isinstance(b, str) or not b.strip() or len(b) > MAX_BODY:
            raise GroupError("bad decrypted content")
        return {"username": u, "body": b}

    # ---- receiving ---------------------------------------------------------------------------------------------
    def _store(self, m: dict, now: float, notify: bool) -> bool:
        """Store a verified message if it belongs to a room I am in.  Returns True if it was stored."""
        room, db = m["room"], self.node.db
        display = None
        if room != ROOM:
            r = db.room_get(room)
            if r is None or not r["joined"] or r["closed"]:
                return False
            if r["kind"] == "private":
                display = self._open(r, m)
            elif len(m["body"]) > MAX_BODY:
                raise GroupError("bad body")
        mine = m["peer"] == self.node.id
        if not db.group_insert(m, mine, now, display):
            return False
        if room != ROOM:
            db.room_set(room, last_ts=m["ts"])
        self.node.emit("group", {"id": m["id"], "room": room})
        if notify and not mine:
            d = display or m
            label = d["username"] if room == ROOM else f"{d['username']} in {db.room_get(room)['name']}"
            self.node.notify_message(m["peer"], label, d["body"], private=False)
        return True

    async def on_gossip(self, conn, m, hops: int) -> bool:
        """Returns True if the message is new (so it should be forwarded)."""
        now = self.node.now()
        try:
            m = verify_message(m, now)
        except GroupError:
            self.node.penalize(conn, 20, "invalid group message")
            return False
        if self.node.db.group_exists(m["id"]) or not self._remember(m["id"]):
            return False                                  # duplicate / replay
        if m["peer"] != self.node.id and not self.author_limiter.allow(m["peer"]):
            return False                                  # author is spamming
        try:
            self._store(m, now, notify=True)              # stores only rooms I joined; everything valid is still forwarded
        except GroupError:
            return False                                  # cannot be opened by me (not from a member): drop, no penalty
        if m["room"] != ROOM:
            r = self.node.db.room_get(m["room"])
            if r is not None and r["kind"] == "public" and not r["joined"]:
                self.node.db.room_set(m["room"], last_ts=m["ts"])     # lets "Discover" show recent activity
        return hops < MAX_HOPS

    # ---- anti-entropy sync -------------------------------------------------
    async def on_sync_req(self, conn, msg) -> dict:
        room = msg.get("room", ROOM)
        if room != ROOM and not (isinstance(room, str) and GID_RE.match(room) and (self.node.db.room_get(room) or {}).get("joined")):
            return {"msgs": []}                           # I only hold history for rooms I am in
        have = {i for i in (msg.get("have") or [])[:300] if isinstance(i, str)}
        since = self.node.now() - SYNC_WINDOW
        return {"msgs": self.node.db.group_since_raw(room, since, have, limit=100)}

    async def sync_with(self, conn) -> int:
        rooms = [ROOM] + [r["gid"] for r in self.node.db.room_list() if r["joined"]][:8]
        added = 0
        for room in rooms:
            have = self.node.db.group_recent_ids(room, 200)
            try:
                res = await conn.request({"t": "sync_req", "room": room, "have": have}, timeout=10)
            except Exception:
                return added
            for m in (res.get("msgs") or [])[:100]:
                try:
                    m = verify_message(m, self.node.now(), window=SYNC_WINDOW)
                    if m["room"] != room or self.node.db.group_exists(m["id"]):
                        continue
                    if self._store(m, self.node.now(), notify=False):
                        added += 1
                except GroupError:
                    self.node.penalize(conn, 10, "invalid message in sync")
        return added
