"""Local HTTP API on 127.0.0.1 used by the Flutter UI (the Flutter <-> Python bridge).

* binds to loopback only
* every request needs the per-launch secret token (X-GC-Token) that Kotlin
  hands to Flutter through a MethodChannel - other apps on the phone cannot
  guess it
* Host header must be loopback (DNS-rebinding protection)
* small request limits; JSON only; Server-Sent Events for live updates
"""
from __future__ import annotations

import asyncio
import hmac
import json
import logging
import os
import re
from urllib.parse import parse_qs, unquote

from ..engine import Engine, EngineError

log = logging.getLogger("gcp2p")
MAX_BODY = 64 * 1024
MAX_MEDIA_BODY = 26 * 1024 * 1024
WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")
_MIME = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
         ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png"}
_CSP = ("default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; media-src blob:; "
        "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
_UI_RE = re.compile(r"^/ui/([0-9a-f]{32})/([A-Za-z0-9_.-]{0,64})$")


class ApiServer:
    def __init__(self, engine: Engine, token: str, host: str = "127.0.0.1", port: int = 0):
        self.engine, self.token, self.host, self.port = engine, token, host, port
        self.server = None
        self.routes = [
            ("GET", r"^/api/state$", self.r_state),
            ("POST", r"^/api/identity/create$", self.r_create),
            ("GET", r"^/api/identity$", self.r_identity),
            ("POST", r"^/api/identity/reset$", self.r_reset),
            ("POST", r"^/api/username$", self.r_username),
            ("GET", r"^/api/peers$", self.r_peers),
            ("POST", r"^/api/peers/refresh$", self.r_refresh),
            ("GET", r"^/api/conversations$", self.r_convs),
            ("GET", r"^/api/dm/(gc[a-z2-7]{32})$", self.r_thread),
            ("POST", r"^/api/dm/(gc[a-z2-7]{32})/read$", self.r_read),
            ("POST", r"^/api/dm/send$", self.r_dm_send),
            ("POST", r"^/api/dm/retry$", self.r_dm_retry),
            ("POST", r"^/api/media/([0-9a-f]{32})/download$", self.r_media_download),
            ("GET", r"^/api/group$", self.r_group),
            ("POST", r"^/api/group/send$", self.r_group_send),
            ("GET", r"^/api/rooms$", self.r_rooms),
            ("POST", r"^/api/rooms/create$", self.r_room_create),
            ("POST", r"^/api/rooms/join$", self.r_room_join),
            ("POST", r"^/api/rooms/leave$", self.r_room_leave),
            ("POST", r"^/api/rooms/close$", self.r_room_close),
            ("GET", r"^/api/rooms/(gr[a-z2-7]{20})$", self.r_room_thread),
            ("POST", r"^/api/rooms/(gr[a-z2-7]{20})/send$", self.r_room_send),
            ("GET", r"^/api/node$", self.r_node),
            ("GET", r"^/api/network$", self.r_network),
            ("GET", r"^/api/settings$", self.r_settings),
            ("POST", r"^/api/settings$", self.r_settings_set),
            ("GET", r"^/api/location$", self.r_loc),
            ("POST", r"^/api/location$", self.r_loc_set),
            ("GET", r"^/api/bootstrap$", self.r_boot),
            ("POST", r"^/api/bootstrap/add$", self.r_boot_add),
            ("POST", r"^/api/bootstrap/remove$", self.r_boot_remove),
            ("POST", r"^/api/connect$", self.r_connect),
        ]

    async def start(self) -> int:
        self.server = await asyncio.start_server(self._client, self.host, self.port)
        self.port = self.server.sockets[0].getsockname()[1]
        return self.port

    async def stop(self) -> None:
        if self.server:
            self.server.close()

    # ------------------------------------------------------------------ http
    async def _client(self, reader, writer):
        try:
            head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 10)
            if len(head) > 16384:
                return await self._send(writer, 431, {"error": "headers too large"})
            lines = head.decode("latin-1").split("\r\n")
            method, target, _ = lines[0].split(" ", 2)
            headers = {}
            for ln in lines[1:]:
                if ":" in ln:
                    k, v = ln.split(":", 1)
                    headers[k.strip().lower()] = v.strip()
            host = headers.get("host", "").rpartition(":")[0] or headers.get("host", "")
            if host not in ("127.0.0.1", "localhost", "[::1]"):
                return await self._send(writer, 403, {"error": "bad host"})
            ui = _UI_RE.match(target.split("?", 1)[0]) if method == "GET" else None
            if ui:   # the page itself: the secret token is part of the URL, API calls then send it as a header
                if not hmac.compare_digest(ui.group(1), self.token):
                    return await self._send(writer, 401, {"error": "unauthorized"})
                return await self._static(writer, ui.group(2) or "index.html")
            if not hmac.compare_digest(headers.get("x-gc-token", ""), self.token):
                return await self._send(writer, 401, {"error": "unauthorized"})
            n = int(headers.get("content-length", "0") or 0)
            path0, _, query = target.partition("?")
            if method == "POST" and path0 == "/api/media/send":
                return await self._media_send(reader, writer, n, query)
            mm = re.match(r"^/api/media/([0-9a-f]{32})$", path0)
            if method == "GET" and mm:
                try:
                    mime, data = self.engine.media_open(mm.group(1))
                except EngineError as exc:
                    return await self._send(writer, 400, {"error": str(exc)})
                writer.write(f"HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\nContent-Length: {len(data)}\r\nCache-Control: no-store\r\n"
                             f"X-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n".encode() + data)
                await writer.drain()
                return
            if n < 0 or n > MAX_BODY:
                return await self._send(writer, 413, {"error": "body too large"})
            body = {}
            if n:
                raw = await asyncio.wait_for(reader.readexactly(n), 10)
                try:
                    body = json.loads(raw.decode("utf-8"))
                except ValueError:
                    return await self._send(writer, 400, {"error": "bad json"})
                if not isinstance(body, dict):
                    return await self._send(writer, 400, {"error": "bad json"})
            path = target.split("?", 1)[0]
            if method == "GET" and path == "/api/events":
                return await self._events(writer)
            for m, pat, fn in self.routes:
                mt = re.match(pat, path)
                if m == method and mt:
                    try:
                        res = await fn(body, *mt.groups())
                    except EngineError as exc:
                        return await self._send(writer, 400, {"error": str(exc)})
                    except Exception:
                        log.exception("api error")
                        return await self._send(writer, 500, {"error": "internal error"})
                    return await self._send(writer, 200, res)
            await self._send(writer, 404, {"error": "not found"})
        except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError, ValueError, asyncio.LimitOverrunError):
            pass
        finally:
            try:
                writer.close()
            except Exception:
                pass

    async def _send(self, writer, status: int, obj) -> None:
        data = json.dumps(obj, separators=(",", ":")).encode()
        reason = {200: "OK", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
                  413: "Payload Too Large", 431: "Header Fields Too Large", 500: "Server Error"}.get(status, "OK")
        writer.write(f"HTTP/1.1 {status} {reason}\r\nContent-Type: application/json\r\nContent-Length: {len(data)}\r\n"
                     f"Cache-Control: no-store\r\nConnection: close\r\n\r\n".encode() + data)
        await writer.drain()

    async def _static(self, writer, name: str) -> None:
        ext = os.path.splitext(name)[1].lower()
        path = os.path.join(WEB_DIR, name)
        if ext not in _MIME or not os.path.isfile(path):
            return await self._send(writer, 404, {"error": "not found"})
        with open(path, "rb") as f:
            data = f.read()
        writer.write(f"HTTP/1.1 200 OK\r\nContent-Type: {_MIME[ext]}\r\nContent-Length: {len(data)}\r\n"
                     f"Cache-Control: no-store\r\nContent-Security-Policy: {_CSP}\r\nReferrer-Policy: no-referrer\r\n"
                     f"X-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n".encode() + data)
        await writer.drain()

    async def _events(self, writer) -> None:
        q: asyncio.Queue = asyncio.Queue(maxsize=500)
        self.engine.subscribers.append(q)
        try:
            writer.write(b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-store\r\n"
                         b"Connection: close\r\n\r\n: connected\n\n")
            await writer.drain()
            while True:
                try:
                    ev = await asyncio.wait_for(q.get(), 15)
                    writer.write(b"data: " + json.dumps(ev, separators=(",", ":")).encode() + b"\n\n")
                except asyncio.TimeoutError:
                    writer.write(b": ping\n\n")
                await writer.drain()
        except (ConnectionError, asyncio.CancelledError, OSError):
            pass
        finally:
            if q in self.engine.subscribers:
                self.engine.subscribers.remove(q)

    # ------------------------------------------------------------------ routes
    async def r_state(self, b):
        return self.engine.state()

    async def r_create(self, b):
        return await self.engine.create_identity(str(b.get("username", "")))

    async def r_identity(self, b):
        return self.engine.identity_info()

    async def r_reset(self, b):
        if b.get("confirm") != "DELETE":
            raise EngineError("Confirmation missing.")
        await self.engine.delete_identity()
        return {"ok": True}

    async def r_username(self, b):
        return await self.engine.set_username(str(b.get("username", "")))

    async def r_peers(self, b):
        return {"peers": self.engine.peers()}

    async def r_refresh(self, b):
        return {"peers": await self.engine.refresh_peers()}

    async def r_convs(self, b):
        return {"conversations": self.engine.conversations()}

    async def r_thread(self, b, peer):
        return self.engine.thread(peer)

    async def r_read(self, b, peer):
        self.engine.mark_read(peer)
        return {"ok": True}

    async def r_dm_send(self, b):
        return await self.engine.send_dm(str(b.get("to", "")), str(b.get("text", "")))

    async def _media_send(self, reader, writer, n: int, query: str) -> None:
        if n <= 0 or n > MAX_MEDIA_BODY:
            return await self._send(writer, 413, {"error": "file too large"})
        q = {k: v[0] for k, v in parse_qs(query, max_num_fields=8).items()}
        data = await asyncio.wait_for(reader.readexactly(n), 180)
        try:
            res = await self.engine.send_media(q.get("to", ""), data, q.get("mime", ""), q.get("once") == "1", unquote(q.get("caption", "")))
        except EngineError as exc:
            return await self._send(writer, 400, {"error": str(exc)})
        await self._send(writer, 200, res)

    async def r_media_download(self, b, mid):
        return await self.engine.media_download(mid)

    async def r_dm_retry(self, b):
        await self.engine.retry_dm(str(b.get("id", "")))
        return {"ok": True}

    async def r_node(self, b):
        return getattr(self.engine, "node_info", None) or {}

    async def r_group(self, b):
        return {"messages": self.engine.group_messages()}

    async def r_group_send(self, b):
        return await self.engine.send_group(str(b.get("text", "")))

    async def r_rooms(self, b):
        return {"rooms": self.engine.rooms()}

    async def r_room_create(self, b):
        return await self.engine.room_create(b.get("name"), b.get("desc", ""), b.get("kind", ""))

    async def r_room_join(self, b):
        return await self.engine.room_join(str(b.get("gid", "")), str(b["invite"]) if b.get("invite") else None)

    async def r_room_leave(self, b):
        return await self.engine.room_leave(str(b.get("gid", "")))

    async def r_room_close(self, b):
        return await self.engine.room_close(str(b.get("gid", "")))

    async def r_room_thread(self, b, gid):
        return self.engine.room_thread(gid)

    async def r_room_send(self, b, gid):
        return await self.engine.room_send(gid, str(b.get("text", "")))

    async def r_network(self, b):
        return self.engine.network()

    async def r_settings(self, b):
        return self.engine.settings()

    async def r_settings_set(self, b):
        return self.engine.update_settings(b)

    async def r_loc(self, b):
        return self.engine.get_location()

    async def r_loc_set(self, b):
        if b.get("shared") is False:
            return await self.engine.set_location(None, None)
        return await self.engine.set_location(b.get("lat"), b.get("lon"), str(b.get("label", "")))

    async def r_boot(self, b):
        return {"bootstrap": self.engine.bootstrap_list()}

    async def r_boot_add(self, b):
        return {"bootstrap": await self.engine.add_bootstrap(str(b.get("addr", "")))}

    async def r_boot_remove(self, b):
        return {"bootstrap": self.engine.remove_bootstrap(str(b.get("addr", "")))}

    async def r_connect(self, b):
        return {"connected": await self.engine.connect_to(str(b.get("addr", "")))}
