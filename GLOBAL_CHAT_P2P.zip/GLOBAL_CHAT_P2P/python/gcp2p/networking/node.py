"""The peer node: connection manager + glue between all services.

Module interaction (see docs/NETWORKING.md for the diagram):

  Node ──owns──> Dht, PresenceService, DmService, GroupService, RelayService
  Node.handlers maps a wire message type ("find_node", "dm", "g", ...) to a
  service method; services call back into Node for connections, broadcast,
  storage and events.  Every connection is authenticated + encrypted.
"""
from __future__ import annotations

import asyncio
import logging
import os
import random
import time

from ..discovery.dht import Dht
from ..encryption import crypto
from ..group_chat.group import GroupService
from ..group_chat.rooms import RoomService
from ..messaging.dm import DmService
from ..messaging.media import MediaService
from ..presence.presence import PRESENCE_TTL, PresenceService
from .link import ChannelError, LinkClosed, SecureChannel, TcpLink, handshake
from .ratelimit import KeyedLimiter, TokenBucket
from .relay import RelayService

log = logging.getLogger("gcp2p")

MIN_CONNS = 4
MAX_CONNS = 48
MAX_ADDRS_TRIED = 4
BAN_SECONDS = 600
KEEPALIVE = 20


class PeerConn:
    def __init__(self, node, chan: SecureChannel, inbound: bool, via_relay: bool = False, dial_addr: str | None = None,
                 observed: str = ""):
        self.node = node
        self.chan = chan
        self.peer_id = chan.remote_id
        self.inbound = inbound
        self.via_relay = via_relay
        self.dial_addr = dial_addr
        self.observed = observed
        self.listen_addrs: list = []
        self.relay_capable = False
        self.ready = asyncio.Event()
        self.pending: dict[int, asyncio.Future] = {}
        self.relay_links: dict = {}
        self.relay_conn: "PeerConn | None" = None
        self.relay_cid: str | None = None
        self.bucket = TokenBucket(rate=40, burst=150, clock=node.now)
        self.score = 0
        self.last_rx = node.now()
        self.opened = node.now()
        self.closed = False
        self.candidate = False
        self._rid = 0
        self.task: asyncio.Task | None = None

    @property
    def initiator_id(self) -> str:
        return self.node.id if not self.inbound else self.peer_id

    async def send(self, obj: dict) -> None:
        if self.closed:
            raise LinkClosed("closed")
        await self.chan.send(obj)

    async def request(self, obj: dict, timeout: float = 8.0) -> dict:
        if self.closed:
            raise LinkClosed("closed")
        self._rid += 1
        rid = self._rid
        fut = asyncio.get_event_loop().create_future()
        self.pending[rid] = fut
        try:
            await self.chan.send({**obj, "rid": rid})
            return await asyncio.wait_for(fut, timeout)
        finally:
            self.pending.pop(rid, None)

    def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        self.chan.close()
        for f in self.pending.values():
            if not f.done():
                f.set_exception(LinkClosed("closed"))
        if self.relay_conn is not None and self.relay_cid:
            asyncio.ensure_future(RelayService._safe_send(self.relay_conn, {"t": "relay_close", "cid": self.relay_cid}))
            self.relay_conn.relay_links.pop(self.relay_cid, None)


class Node:
    def __init__(self, identity, username: str, db, *, listen: bool = True, host: str = "0.0.0.0", port: int = 0,
                 store_forward: bool = True, relay_service: bool = True, clock=time.time,
                 media_dir: str | None = None, storage_key: bytes | None = None):
        self.identity = identity
        self.id = identity.peer_id
        self.username = username
        self.media_dir = media_dir
        self.storage_key = storage_key
        self.location: list | None = None     # [lat, lon] rounded to 0.1 deg, only if the user opted in
        self.db = db
        self.listen = listen
        self.host = host
        self.port = port
        self.store_forward = store_forward
        self.clock = clock
        self.handlers: dict = {}
        self.conns: dict[str, PeerConn] = {}
        self.server: asyncio.AbstractServer | None = None
        self.tasks: list[asyncio.Task] = []
        self._bg: set = set()
        self.subscribers: list[asyncio.Queue] = []
        self.public_addrs: set[str] = set()
        self.reachability = "unknown"        # unknown | public | private
        self.banned: dict[str, float] = {}
        self._dialing: dict[str, asyncio.Future] = {}
        self._dial_sem = asyncio.Semaphore(12)
        self._dialback_last: dict[str, float] = {}
        self.store_limiter = KeyedLimiter(rate=0.2, burst=10, clock=self.now)
        self.notifier = None                 # optional callback(peer, name, text, private)
        self.started = False
        self.lan = None
        self.stats = {"rx": 0, "tx": 0, "dials": 0, "dial_fail": 0}

        self.dht = Dht(self)
        self.presence = PresenceService(self)
        self.group = GroupService(self)
        self.rooms = RoomService(self)
        self.dm = DmService(self)
        self.media = MediaService(self)
        self.relay = RelayService(self)
        self.relay.enabled = relay_service
        self.handlers["ping"] = self._on_ping
        self.handlers["info"] = self._on_info
        self.handlers["g"] = self._on_gossip
        self.handlers["dialback"] = self._on_dialback

    # ---------------------------------------------------------------- utilities
    def now(self) -> float:
        return self.clock()

    def emit(self, kind: str, data: dict | None = None) -> None:
        ev = {"type": kind, "data": data or {}, "ts": self.now()}
        for q in list(self.subscribers):
            try:
                q.put_nowait(ev)
            except asyncio.QueueFull:
                pass

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=500)
        self.subscribers.append(q)
        return q

    def unsubscribe(self, q) -> None:
        if q in self.subscribers:
            self.subscribers.remove(q)

    def notify_message(self, peer: str, name: str, text: str, private: bool) -> None:
        if self.notifier:
            try:
                self.notifier(peer, name, text, private)
            except Exception:
                log.exception("notifier failed")

    def spawn(self, coro) -> asyncio.Task:
        t = asyncio.ensure_future(coro)
        self._bg.add(t)
        t.add_done_callback(self._bg.discard)
        return t

    def can_relay(self) -> bool:
        return self.reachability == "public" and bool(self.public_addrs)

    def store_forward_available(self) -> bool:
        return True

    def advertised_addrs(self) -> list:
        addrs = sorted(self.public_addrs)
        addrs += [a for a in self.relay.my_relays.values() if a not in addrs]
        return addrs[:8]

    def set_username(self, name: str) -> None:
        self.username = name

    # ------------------------------------------------------------------ lifecycle
    async def start(self) -> None:
        if self.listen:
            self.server = await asyncio.start_server(self._on_inbound, self.host, self.port)
            self.port = self.server.sockets[0].getsockname()[1]
        self.started = True
        self.tasks = [asyncio.ensure_future(self._maintenance())]

    async def stop(self) -> None:
        if not self.started:
            return
        self.started = False
        try:
            await asyncio.wait_for(self.presence.publish(ttl=0), 3)   # signed "I am going offline"
        except Exception:
            pass
        for t in self.tasks + list(self._bg):
            t.cancel()
        if self.lan:
            self.lan.stop()
        if self.server:
            self.server.close()
        for c in list(self.conns.values()):
            c.close()
        self.conns.clear()
        await asyncio.sleep(0)

    # ------------------------------------------------------------------ connections
    async def _on_inbound(self, reader, writer) -> None:
        if len(self.conns) >= MAX_CONNS + 16:
            writer.close()
            return
        link = TcpLink(reader, writer)
        try:
            chan = await handshake(link, self.identity, False)
        except ChannelError:
            return
        if self.banned.get(chan.remote_id, 0) > self.now():
            chan.close()
            return
        conn = PeerConn(self, chan, inbound=True, observed=f"{link.ip}:{link.port}")
        await self._register(conn)

    async def accept_relayed(self, link, relay_conn: PeerConn, cid: str) -> None:
        try:
            chan = await handshake(link, self.identity, False, timeout=12)
        except ChannelError:
            relay_conn.relay_links.pop(cid, None)
            return
        if self.banned.get(chan.remote_id, 0) > self.now():
            chan.close()
            return
        conn = PeerConn(self, chan, inbound=True, via_relay=True)
        conn.relay_conn, conn.relay_cid = relay_conn, cid
        await self._register(conn)

    async def _register(self, conn: PeerConn) -> None:
        old = self.conns.get(conn.peer_id)
        if old is not None and not old.closed:
            conn.candidate = True    # decided when the peer proves it is a real session (sends `info`)
        else:
            self.conns[conn.peer_id] = conn
        conn.task = asyncio.ensure_future(self._read_loop(conn))
        try:
            await conn.send({"t": "info", "addrs": self.advertised_addrs(), "relay": self.can_relay(),
                             "observed": conn.observed, "port": self.port if self.listen else 0})
        except Exception:
            self._drop(conn)

    def _drop(self, conn: PeerConn) -> None:
        conn.close()
        current = self.conns.get(conn.peer_id) is conn
        if current:
            self.conns.pop(conn.peer_id, None)
        self.relay.conn_closed(conn)
        if current and conn.ready.is_set():
            self.emit("peer_disconnected", {"peer": conn.peer_id})
            self.emit("presence", {"peer": conn.peer_id})

    async def _read_loop(self, conn: PeerConn) -> None:
        try:
            while True:
                msg = await conn.chan.recv()
                conn.last_rx = self.now()
                self.stats["rx"] += 1
                if not conn.bucket.allow():
                    self.penalize(conn, 2, "rate limit")
                    continue
                if msg.get("t") == "r":
                    fut = conn.pending.get(msg.get("rid"))
                    if fut and not fut.done():
                        fut.set_result(msg)
                    continue
                self.spawn(self._handle(conn, msg))
        except (LinkClosed, ChannelError, asyncio.CancelledError):
            pass
        except Exception:
            log.exception("read loop crashed")
        finally:
            self._drop(conn)

    async def _handle(self, conn: PeerConn, msg: dict) -> None:
        t, rid = msg.get("t"), msg.get("rid")
        h = self.handlers.get(t) if isinstance(t, str) else None
        if h is None:
            self.penalize(conn, 5, "unknown message type")
            if rid is not None:
                await self._reply(conn, rid, {"err": "unknown"})
            return
        try:
            res = await h(conn, msg)
        except Exception as exc:
            log.exception("handler %s failed", t)
            res = {"err": type(exc).__name__}
        if rid is not None:
            await self._reply(conn, rid, res or {})

    async def _reply(self, conn, rid, body: dict) -> None:
        try:
            await conn.send({"t": "r", "rid": rid, **body})
        except Exception:
            pass

    def penalize(self, conn: PeerConn, pts: int, reason: str) -> None:
        conn.score += pts
        log.debug("penalty %s +%d (%s)", conn.peer_id, pts, reason)
        if conn.score >= 100:
            self.banned[conn.peer_id] = self.now() + BAN_SECONDS
            self._drop(conn)

    # ------------------------------------------------------------------ handlers
    async def _on_ping(self, conn, msg) -> dict:
        return {"ok": True}

    async def _on_info(self, conn, msg) -> None:
        if conn.candidate:
            old = self.conns.get(conn.peer_id)
            if old is not None and not old.closed:
                # keep the connection initiated by the smaller peer id (both sides reach the same answer)
                if not (conn.initiator_id <= old.initiator_id):
                    conn.close()
                    return
                old.close()
            conn.candidate = False
            self.conns[conn.peer_id] = conn
        addrs = [a for a in (msg.get("addrs") or [])[:8] if isinstance(a, str) and len(a) < 160]
        conn.listen_addrs = addrs
        conn.relay_capable = bool(msg.get("relay"))
        self.dht.add_peer(conn.peer_id, conn.listen_addrs or ([conn.dial_addr] if conn.dial_addr else []))
        self.db.upsert_peer(conn.peer_id, addrs=conn.listen_addrs or None, seen=self.now())
        was_ready = conn.ready.is_set()
        if was_ready and conn.relay_capable and self.reachability != "public" and not self.relay.my_relays:
            self.spawn(self._ensure_relay())
        if not was_ready:
            conn.ready.set()
            self.emit("peer_connected", {"peer": conn.peer_id})
            self.emit("presence", {"peer": conn.peer_id})
            self.spawn(self._after_connect(conn, msg))

    async def _after_connect(self, conn: PeerConn, info: dict) -> None:
        """Run right after a peer becomes ready: learn our address, sync state."""
        try:
            await self._learn_reachability(conn, info.get("observed", ""))
            await self.presence.sync_from(conn)
            await self.rooms.sync_from(conn)
            await self.group.sync_with(conn)
            await self.dm.fetch_mailbox()
            await self.dm.pump_outbox()
        except Exception:
            log.debug("after_connect failed", exc_info=True)

    async def _on_gossip(self, conn, msg) -> None:
        kind, m, hops = msg.get("k"), msg.get("m"), msg.get("h", 0)
        if not isinstance(hops, int) or hops < 0 or hops > 16:
            return
        svc = {"grp": self.group, "pres": self.presence, "grec": self.rooms}.get(kind)
        if svc is None:
            self.penalize(conn, 5, "unknown gossip kind")
            return
        if await svc.on_gossip(conn, m, hops):
            await self.broadcast({"t": "g", "k": kind, "m": m, "h": hops + 1}, exclude=conn.peer_id, fanout=8)

    async def broadcast(self, msg: dict, exclude: str | None = None, fanout: int = 8) -> None:
        peers = [c for c in self.conns.values() if c.ready.is_set() and c.peer_id != exclude and not c.closed]
        random.shuffle(peers)
        for c in peers[:fanout]:
            try:
                await c.send(msg)
                self.stats["tx"] += 1
            except Exception:
                continue

    # ------------------------------------------------------------------ reachability (AutoNAT-lite)
    async def _on_dialback(self, conn, msg) -> dict:
        """Dial the requester back at the IP we see it coming from, to prove it is publicly reachable."""
        port = msg.get("port")
        now = self.now()
        if conn.via_relay or not isinstance(port, int) or not (0 < port < 65536):
            return {"ok": False}
        if now - self._dialback_last.get(conn.peer_id, 0) < 20:
            return {"ok": False, "err": "too soon"}
        self._dialback_last[conn.peer_id] = now
        ip = conn.observed.rpartition(":")[0]
        if not ip:
            return {"ok": False}
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(ip, port), 5)
            chan = await handshake(TcpLink(reader, writer), self.identity, True, expect_peer=conn.peer_id, timeout=6)
            chan.close()
            return {"ok": True, "addr": f"{ip}:{port}"}
        except Exception:
            return {"ok": False}

    async def _learn_reachability(self, conn: PeerConn, observed: str) -> None:
        if conn.via_relay or self.reachability == "public":
            return
        if not self.listen:
            self.reachability = "private"
            await self._ensure_relay()
            return
        ip = observed.rpartition(":")[0]
        if not ip:
            return
        try:
            r = await conn.request({"t": "dialback", "port": self.port}, timeout=10)
        except Exception:
            return
        addr = r.get("addr")
        if r.get("ok") and isinstance(addr, str) and addr.endswith(f":{self.port}"):
            self.public_addrs.add(addr)        # the address the *other* peer actually reached us at
            self.reachability = "public"
            self.emit("network", {})
            await self._push_info()
            await self.presence.publish()
        else:
            self.reachability = "private"
            await self._ensure_relay()

    async def _push_info(self) -> None:
        for c in list(self.conns.values()):
            if c.ready.is_set():
                try:
                    await c.send({"t": "info", "addrs": self.advertised_addrs(), "relay": self.can_relay(),
                                  "observed": c.observed, "port": self.port if self.listen else 0})
                except Exception:
                    pass

    async def _ensure_relay(self) -> None:
        if self.reachability == "public" or self.relay.my_relays:
            return
        for c in list(self.conns.values()):
            if c.ready.is_set() and c.relay_capable and not c.via_relay and c.dial_addr:
                if await self.relay.reserve(c):
                    self.emit("network", {})
                    await self._push_info()
                    await self.presence.publish()
                    return

    # ------------------------------------------------------------------ dialing
    async def connect(self, addr: str, expect_peer: str | None = None) -> PeerConn | None:
        """Open an outbound authenticated connection.  addr is 'host:port' or 'r/<relay id>/<host:port>'."""
        if addr.startswith("r/"):
            return await self._dial_relay(addr, expect_peer)
        host, _, port = addr.rpartition(":")
        if not host or not port.isdigit() or not (0 < int(port) < 65536):
            return None
        self.stats["dials"] += 1
        async with self._dial_sem:
            try:
                reader, writer = await asyncio.wait_for(asyncio.open_connection(host.strip("[]"), int(port)), 6)
            except (OSError, asyncio.TimeoutError):
                self.stats["dial_fail"] += 1
                return None
            try:
                chan = await handshake(TcpLink(reader, writer), self.identity, True, expect_peer=expect_peer)
            except ChannelError:
                self.stats["dial_fail"] += 1
                return None
        if self.banned.get(chan.remote_id, 0) > self.now():
            chan.close()
            return None
        conn = PeerConn(self, chan, inbound=False, dial_addr=addr, observed=f"{chan.link.ip}:{chan.link.port}")
        await self._register(conn)
        c = self.conns.get(conn.peer_id)
        if c is not None and not c.closed:
            try:
                await asyncio.wait_for(c.ready.wait(), 6)
            except asyncio.TimeoutError:
                pass
        return self.conns.get(conn.peer_id)

    async def _dial_relay(self, addr: str, expect_peer: str | None) -> PeerConn | None:
        parts = addr.split("/", 2)
        if len(parts) != 3 or not expect_peer or not crypto.valid_peer_id(parts[1]):
            return None
        relay_id, relay_addr = parts[1], parts[2]
        rc = self.conns.get(relay_id) or await self.connect(relay_addr, expect_peer=relay_id)
        if rc is None:
            return None
        try:
            chan, cid = await self.relay.dial_via(rc, expect_peer)
        except Exception:
            return None
        conn = PeerConn(self, chan, inbound=False, via_relay=True, dial_addr=addr)
        conn.relay_conn, conn.relay_cid = rc, cid
        await self._register(conn)
        c = self.conns.get(conn.peer_id)
        if c is not None and not c.closed:
            try:
                await asyncio.wait_for(c.ready.wait(), 6)
            except asyncio.TimeoutError:
                pass
        return self.conns.get(conn.peer_id)

    async def get_conn(self, peer_id: str, addrs: list | None = None) -> PeerConn | None:
        c = self.conns.get(peer_id)
        if c is not None and not c.closed and c.ready.is_set():
            return c
        if peer_id == self.id or self.banned.get(peer_id, 0) > self.now():
            return None
        fut = self._dialing.get(peer_id)
        if fut is not None:
            try:
                return await asyncio.shield(fut)
            except Exception:
                return None
        fut = asyncio.get_event_loop().create_future()
        self._dialing[peer_id] = fut
        result = None
        try:
            cands = list(addrs or [])
            for a in (self.db.get_peer(peer_id) or {}).get("addrs", []):
                if a not in cands:
                    cands.append(a)
            for a in sorted(cands, key=lambda x: x.startswith("r/"))[:MAX_ADDRS_TRIED]:  # direct first, relays last
                result = await self.connect(a, expect_peer=peer_id)
                if result is not None:
                    break
            self.db.mark_peer_failure(peer_id, result is not None)
        except Exception:
            result = None
        finally:
            self._dialing.pop(peer_id, None)
            fut.set_result(result)
        return result

    # ------------------------------------------------------------------ maintenance
    async def _maintenance(self) -> None:
        tick = 0
        await asyncio.sleep(0.2)
        while self.started:
            try:
                tick += 1
                await self._bootstrap_if_needed()
                await self._keepalive()
                if tick % 2 == 0:
                    await self.dm.pump_outbox()
                    await self.media.retry_pending()
                if tick % 3 == 1:
                    await self.dm.fetch_mailbox()
                if tick % 6 == 2:
                    await self.presence.publish()
                    await self.rooms.announce()
                    self.presence.expire()
                    self.db.mbox_expire(self.now())
                    self.db.rec_expire(self.now())
                    self.media.expire()
                if tick % 9 == 3:
                    ready = [c for c in self.conns.values() if c.ready.is_set()]
                    if ready:
                        await self.group.sync_with(random.choice(ready))
                self._trim()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("maintenance error")
            await asyncio.sleep(self.tick_seconds)

    tick_seconds = 5.0

    async def _bootstrap_if_needed(self) -> None:
        ready = [c for c in self.conns.values() if c.ready.is_set()]
        if len(ready) >= MIN_CONNS:
            return
        targets = list(self.db.list_bootstrap())
        for p in self.db.list_peers(limit=60):
            if p["peer_id"] not in self.conns and p["addrs"] and p["failures"] < 5 and p["peer_id"] != self.id:
                targets.append((p["peer_id"], p["addrs"]))
        random.shuffle(targets)
        for t in targets[:4]:
            if isinstance(t, tuple):
                await self.get_conn(t[0], t[1])
            else:
                if any(c.dial_addr == t for c in self.conns.values()):
                    continue
                peer = None
                addr = t
                if "@" in t:
                    peer, addr = t.split("@", 1)
                    if not crypto.valid_peer_id(peer):
                        continue
                await self.connect(addr, expect_peer=peer)
            if len([c for c in self.conns.values() if c.ready.is_set()]) >= MIN_CONNS:
                break
        if self.conns and self.reachability == "private":
            await self._ensure_relay()
        if self.conns:
            # fill the routing table
            try:
                await self.dht.lookup(self.dht.table.self_nid)
            except Exception:
                pass

    async def _keepalive(self) -> None:
        now = self.now()
        for c in list(self.conns.values()):
            if c.closed:
                self._drop(c)
            elif now - c.last_rx > KEEPALIVE * 3:
                self._drop(c)
            elif now - c.last_rx > KEEPALIVE and c.ready.is_set():
                async def ping(c=c):
                    try:
                        await c.request({"t": "ping"}, timeout=8)
                    except Exception:
                        self._drop(c)
                self.spawn(ping())

    def _trim(self) -> None:
        if len(self.conns) <= MAX_CONNS:
            return
        boots = set(self.db.list_bootstrap())
        victims = sorted((c for c in self.conns.values() if c.dial_addr not in boots), key=lambda c: c.last_rx)
        for c in victims[: len(self.conns) - MAX_CONNS]:
            self._drop(c)

    def kick(self) -> None:
        """Network changed (Wi-Fi <-> mobile data): drop stale sessions, forget our old address, reconnect."""
        for c in list(self.conns.values()):
            self._drop(c)
        self.public_addrs.clear()
        self.relay.my_relays.clear()
        self.reachability = "unknown"
        self.emit("network", {})

    # ------------------------------------------------------------------ status
    def network_status(self) -> dict:
        ready = [c for c in self.conns.values() if c.ready.is_set()]
        return {
            "peer_id": self.id,
            "listening": self.server is not None,
            "port": self.port if self.server else 0,
            "reachability": self.reachability,
            "addresses": self.advertised_addrs(),
            "connections": len(ready),
            "direct": sum(1 for c in ready if not c.via_relay),
            "relayed": sum(1 for c in ready if c.via_relay),
            "routing_table": self.dht.table.size(),
            "relay_enabled": self.relay.enabled and self.can_relay(),
            "relay_clients": len(self.relay.reservations),
            "my_relays": list(self.relay.my_relays.keys()),
            "mailbox_held": self.db.mbox_count(),
            "banned": sum(1 for t in self.banned.values() if t > self.now()),
            "stats": dict(self.stats),
            "peers": [{"peer_id": c.peer_id, "inbound": c.inbound, "relayed": c.via_relay,
                       "addr": c.dial_addr or c.observed} for c in ready],
        }
