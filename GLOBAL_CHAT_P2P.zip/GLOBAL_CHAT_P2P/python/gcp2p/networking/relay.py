"""Circuit relay.

A peer that cannot accept inbound connections (phone behind mobile-carrier
NAT) keeps an outbound connection to a publicly reachable peer and asks it
for a reservation.  Other peers reach it through that relay:

    B --(relay_connect)--> R --(relay_incoming)--> A
    B <==== end-to-end authenticated + encrypted handshake through R ====> A

After the handshake the relay only forwards ciphertext; it cannot read or
modify messages, and it cannot impersonate either side.  Relays are
untrusted and limited (slots, bytes, lifetime) so they cannot become a
central server.
"""
from __future__ import annotations

import asyncio
import os

from ..encryption import crypto
from .link import ChannelError, LinkClosed, QueueLink, handshake

MAX_RESERVATIONS = 64
MAX_CIRCUITS = 128
MAX_CIRCUIT_BYTES = 8 * 1024 * 1024
MAX_CIRCUIT_SECONDS = 3600


class Circuit:
    __slots__ = ("cid", "a", "b", "bytes", "started")

    def __init__(self, cid, a, b, started):
        self.cid, self.a, self.b, self.bytes, self.started = cid, a, b, 0, started


class RelayService:
    def __init__(self, node):
        self.node = node
        self.enabled = True
        self.reservations: dict[str, object] = {}   # peer_id -> PeerConn (relay side)
        self.circuits: dict[str, Circuit] = {}       # relay side
        self.my_relays: dict[str, str] = {}          # relay peer id -> advertised r/ address (client side)
        h = node.handlers
        h["relay_reserve"] = self.on_reserve
        h["relay_connect"] = self.on_connect
        h["relay_incoming"] = self.on_incoming
        h["rf"] = self.on_frame
        h["relay_close"] = self.on_close

    # ---------------- relay side ----------------
    async def on_reserve(self, conn, msg) -> dict:
        if not (self.enabled and self.node.can_relay()):
            return {"ok": False, "err": "relaying disabled"}
        if conn.peer_id not in self.reservations and len(self.reservations) >= MAX_RESERVATIONS:
            return {"ok": False, "err": "no free slots"}
        self.reservations[conn.peer_id] = conn
        return {"ok": True}

    async def on_connect(self, conn, msg) -> dict:
        target, cid = msg.get("target"), str(msg.get("cid", ""))
        if not self.enabled or not crypto.valid_peer_id(target) or not (8 <= len(cid) <= 32):
            return {"ok": False, "err": "bad request"}
        a = self.reservations.get(target)
        if a is None or not a.ready.is_set() or a is conn:
            return {"ok": False, "err": "target not reserved here"}
        if len(self.circuits) >= MAX_CIRCUITS or cid in self.circuits:
            return {"ok": False, "err": "busy"}
        c = Circuit(cid, conn, a, self.node.now())
        self.circuits[cid] = c
        try:
            r = await a.request({"t": "relay_incoming", "cid": cid, "from": conn.peer_id}, timeout=6)
            if not r.get("ok"):
                raise RuntimeError("target refused")
        except Exception:
            self.circuits.pop(cid, None)
            return {"ok": False, "err": "target unreachable"}
        return {"ok": True}

    async def on_frame(self, conn, msg) -> None:
        cid = str(msg.get("c", ""))
        data = msg.get("d")
        link = conn.relay_links.get(cid)
        if link is not None:                      # we are an endpoint of this circuit
            try:
                link.feed(crypto.b64d(data))
            except crypto.CryptoError:
                link.close()
            return
        c = self.circuits.get(cid)                # we are the relay
        if c is None or conn not in (c.a, c.b) or not isinstance(data, str):
            return
        c.bytes += len(data)
        if c.bytes > MAX_CIRCUIT_BYTES or self.node.now() - c.started > MAX_CIRCUIT_SECONDS:
            await self._close_circuit(cid)
            return
        other = c.b if conn is c.a else c.a
        try:
            await other.send({"t": "rf", "c": cid, "d": data})
        except Exception:
            await self._close_circuit(cid)

    async def on_close(self, conn, msg) -> None:
        cid = str(msg.get("cid", ""))
        link = conn.relay_links.pop(cid, None)
        if link:
            link.close()
        c = self.circuits.get(cid)
        if c and conn in (c.a, c.b):
            await self._close_circuit(cid)

    async def _close_circuit(self, cid: str) -> None:
        c = self.circuits.pop(cid, None)
        if not c:
            return
        for end in (c.a, c.b):
            try:
                await end.send({"t": "relay_close", "cid": cid})
            except Exception:
                pass

    def conn_closed(self, conn) -> None:
        if self.reservations.get(conn.peer_id) is conn:
            self.reservations.pop(conn.peer_id, None)
        for cid, c in list(self.circuits.items()):
            if conn in (c.a, c.b):
                self.circuits.pop(cid, None)
                other = c.b if conn is c.a else c.a
                asyncio.ensure_future(self._safe_send(other, {"t": "relay_close", "cid": cid}))
        for link in list(conn.relay_links.values()):
            link.close()
        conn.relay_links.clear()
        for rid, addr in list(self.my_relays.items()):
            if rid == conn.peer_id:
                self.my_relays.pop(rid, None)

    @staticmethod
    async def _safe_send(conn, obj):
        try:
            await conn.send(obj)
        except Exception:
            pass

    # ---------------- client side (we are behind NAT) ----------------
    async def reserve(self, relay_conn) -> bool:
        if relay_conn.dial_addr is None or relay_conn.via_relay:
            return False
        try:
            r = await relay_conn.request({"t": "relay_reserve"}, timeout=6)
        except Exception:
            return False
        if r.get("ok"):
            self.my_relays[relay_conn.peer_id] = f"r/{relay_conn.peer_id}/{relay_conn.dial_addr}"
            return True
        return False

    async def on_incoming(self, conn, msg) -> dict:
        cid = str(msg.get("cid", ""))
        if not (8 <= len(cid) <= 32) or conn.peer_id not in self.my_relays:
            return {"ok": False}
        link = self._make_link(conn, cid)
        asyncio.ensure_future(self.node.accept_relayed(link, conn, cid))
        return {"ok": True}

    def _make_link(self, conn, cid: str) -> QueueLink:
        async def send(data: bytes):
            await conn.send({"t": "rf", "c": cid, "d": crypto.b64e(data)})

        link = QueueLink(send)
        conn.relay_links[cid] = link
        return link

    # ---------------- client side: dialing through a relay ----------------
    async def dial_via(self, relay_conn, target: str):
        """Open a circuit to `target` through `relay_conn`, return a secure channel."""
        cid = os.urandom(8).hex()
        link = self._make_link(relay_conn, cid)
        try:
            r = await relay_conn.request({"t": "relay_connect", "target": target, "cid": cid}, timeout=8)
            if not r.get("ok"):
                raise ChannelError(r.get("err", "relay refused"))
            chan = await handshake(link, self.node.identity, True, expect_peer=target, timeout=12)
        except (ChannelError, LinkClosed, asyncio.TimeoutError, OSError, Exception):
            relay_conn.relay_links.pop(cid, None)
            link.close()
            raise
        return chan, cid
