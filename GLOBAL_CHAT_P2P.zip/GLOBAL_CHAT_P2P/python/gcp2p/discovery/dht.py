"""Kademlia-style DHT: XOR metric, k-buckets, iterative lookups.

Used for (a) finding peers, (b) publishing/finding signed presence records,
and (c) choosing the nodes that hold encrypted offline mailboxes.
Records are self-certifying (signed by their owner) so storage nodes cannot
alter them.
"""
from __future__ import annotations

import asyncio

from ..encryption import crypto
from ..presence.presence import RecordError, verify_record

K = 16          # bucket size / lookup width
ALPHA = 3       # parallel queries
REPLICAS = 3    # copies of each stored record
MAX_NODES_IN_REPLY = 16


class PeerInfo:
    __slots__ = ("peer_id", "addrs", "nid")

    def __init__(self, peer_id: str, addrs: list):
        self.peer_id = peer_id
        self.addrs = list(addrs)[:8]
        self.nid = crypto.node_id(peer_id)


class RoutingTable:
    def __init__(self, self_id: str):
        self.self_nid = crypto.node_id(self_id)
        self.buckets: dict[int, list[PeerInfo]] = {}

    def _idx(self, nid: int) -> int:
        return (self.self_nid ^ nid).bit_length() - 1

    def add(self, info: PeerInfo, connected=lambda pid: False) -> None:
        if info.nid == self.self_nid:
            return
        b = self.buckets.setdefault(self._idx(info.nid), [])
        for i, e in enumerate(b):
            if e.peer_id == info.peer_id:
                b.pop(i)
                b.append(info)  # most recently seen at the tail
                return
        if len(b) < K:
            b.append(info)
            return
        for i, e in enumerate(b):  # evict least-recent peer that is not connected
            if not connected(e.peer_id):
                b.pop(i)
                b.append(info)
                return

    def remove(self, peer_id: str) -> None:
        for b in self.buckets.values():
            for i, e in enumerate(b):
                if e.peer_id == peer_id:
                    b.pop(i)
                    return

    def all(self) -> list:
        return [e for b in self.buckets.values() for e in b]

    def closest(self, target: int, n: int = K) -> list:
        return sorted(self.all(), key=lambda e: e.nid ^ target)[:n]

    def size(self) -> int:
        return sum(len(b) for b in self.buckets.values())


class Dht:
    def __init__(self, node):
        self.node = node
        self.table = RoutingTable(node.id)
        node.handlers["find_node"] = self.on_find_node
        node.handlers["find_value"] = self.on_find_value
        node.handlers["store"] = self.on_store

    # ---- table maintenance -------------------------------------------------
    def add_peer(self, peer_id: str, addrs: list) -> None:
        if crypto.valid_peer_id(peer_id) and peer_id != self.node.id:
            self.table.add(PeerInfo(peer_id, addrs), connected=lambda p: p in self.node.conns)

    def _infos(self, target: int, exclude: str | None = None) -> list:
        out = []
        for e in self.table.closest(target, MAX_NODES_IN_REPLY + 1):
            if e.peer_id != exclude:
                out.append({"id": e.peer_id, "addrs": e.addrs})
        return out[:MAX_NODES_IN_REPLY]

    # ---- handlers -----------------------------------------------------------
    async def on_find_node(self, conn, msg) -> dict:
        target = _target(msg)
        return {"nodes": self._infos(target, exclude=conn.peer_id)}

    async def on_find_value(self, conn, msg) -> dict:
        target = _target(msg)
        key = str(msg.get("key", ""))[:80]
        rec = self.node.db.rec_get(key, self.node.now())
        return {"rec": rec, "nodes": self._infos(target, exclude=conn.peer_id)}

    async def on_store(self, conn, msg) -> dict:
        if msg.get("kind") != "presence":
            return {"ok": False, "err": "unsupported kind"}
        try:
            rec = verify_record(msg.get("rec"), self.node.now())
        except RecordError:
            self.node.penalize(conn, 20, "invalid record")
            return {"ok": False, "err": "invalid"}
        if not self.node.store_limiter.allow(conn.peer_id):
            return {"ok": False, "err": "rate limited"}
        self._store_local(rec)
        return {"ok": True}

    def _store_local(self, rec: dict) -> bool:
        key = "presence|" + rec["peer"]
        expires = rec["ts"] + max(rec["ttl"], 60) + 60
        return self.node.db.rec_put(key, "presence", rec, rec["ts"], expires)

    # ---- iterative lookup ------------------------------------------------------
    async def lookup(self, target: int, key: str | None = None):
        """Return (closest peers that answered, record or None)."""
        shortlist: dict[str, PeerInfo] = {e.peer_id: e for e in self.table.closest(target, K)}
        for pid, c in list(self.node.conns.items()):  # connected peers are always candidates
            if c.ready.is_set() and pid not in shortlist:
                shortlist[pid] = PeerInfo(pid, c.listen_addrs)
        queried: set[str] = set()
        answered: dict[str, PeerInfo] = {}
        found = None
        for _ in range(6):
            cand = sorted((p for p in shortlist.values() if p.peer_id not in queried),
                          key=lambda p: p.nid ^ target)[:ALPHA]
            if not cand:
                break
            msg = {"t": "find_value", "target": hex(target), "key": key} if key else {"t": "find_node", "target": hex(target)}
            results = await asyncio.gather(*[self._ask(p, msg) for p in cand], return_exceptions=True)
            for p, res in zip(cand, results):
                queried.add(p.peer_id)
                if not isinstance(res, dict):
                    continue
                answered[p.peer_id] = p
                rec = res.get("rec")
                if key and rec:
                    try:
                        rec = verify_record(rec, self.node.now())
                        if found is None or rec["ts"] > found["ts"]:
                            found = rec
                    except RecordError:
                        pass
                for n in (res.get("nodes") or [])[:MAX_NODES_IN_REPLY]:
                    try:
                        pid, addrs = n["id"], n.get("addrs") or []
                        if crypto.valid_peer_id(pid) and pid != self.node.id and isinstance(addrs, list):
                            shortlist.setdefault(pid, PeerInfo(pid, [a for a in addrs if isinstance(a, str)]))
                            self.add_peer(pid, [a for a in addrs if isinstance(a, str)])
                    except (KeyError, TypeError):
                        continue
        closest = sorted(answered.values(), key=lambda p: p.nid ^ target)[:K]
        return closest, found

    async def _ask(self, p: PeerInfo, msg: dict):
        conn = await self.node.get_conn(p.peer_id, p.addrs)
        if conn is None:
            self.table.remove(p.peer_id)
            return None
        return await conn.request(msg, timeout=8)

    # ---- records ---------------------------------------------------------------
    async def store_record(self, rec: dict) -> int:
        """Store a presence record locally and on the closest peers."""
        self._store_local(rec)
        target = crypto.key_id("presence", rec["peer"])
        closest, _ = await self.lookup(target)
        n = 0
        for p in closest[:REPLICAS]:
            conn = self.node.conns.get(p.peer_id)
            if conn is None:
                continue
            try:
                r = await conn.request({"t": "store", "kind": "presence", "rec": rec}, timeout=6)
                n += 1 if r.get("ok") else 0
            except Exception:
                pass
        return n

    async def find_presence(self, peer_id: str):
        key = "presence|" + peer_id
        local = self.node.db.rec_get(key, self.node.now())
        _, remote = await self.lookup(crypto.key_id("presence", peer_id), key=key)
        best = None
        for r in (local, remote):
            if r:
                try:
                    r = verify_record(r, self.node.now())
                except RecordError:
                    continue
                if best is None or r["ts"] > best["ts"]:
                    best = r
        return best

    def replica_set(self, closest: list, target: int) -> list:
        """Peer ids (possibly including ourselves) that should hold a key."""
        ids = [(p.nid ^ target, p.peer_id) for p in closest]
        ids.append((self.table.self_nid ^ target, self.node.id))
        ids.sort()
        return [pid for _, pid in ids[:REPLICAS]]


def _target(msg) -> int:
    try:
        return int(str(msg.get("target", "0")), 16)
    except ValueError:
        return 0
