"""Local-network discovery (UDP broadcast beacons).

Lets two phones on the same Wi-Fi find each other with no bootstrap server.
Beacons are signed (peer id + listening port + time) so they cannot be
forged or replayed for long; we then open a normal authenticated connection.
"""
from __future__ import annotations

import asyncio
import json
import socket
import time

from ..encryption import crypto

LAN_PORT = 47474
BEACON_EVERY = 15.0


def make_beacon(identity, port: int, ts: float | None = None) -> bytes:
    body = {"v": 1, "peer": identity.peer_id, "pub": crypto.b64e(identity.pub), "port": port,
            "ts": round(ts if ts is not None else time.time(), 3)}
    body["sig"] = crypto.b64e(identity.sign(b"gcp2p-lan|" + crypto.canonical(body)))
    return json.dumps(body, separators=(",", ":")).encode()


def parse_beacon(data: bytes, now: float):
    """Return (peer_id, port) for a valid, fresh beacon, else None."""
    try:
        b = json.loads(data.decode("utf-8"))
        pub, sig = crypto.b64d(b["pub"]), crypto.b64d(b["sig"])
        port, ts, peer = b["port"], b["ts"], b["peer"]
        body = {k: v for k, v in b.items() if k != "sig"}
    except Exception:
        return None
    if set(b) != {"v", "peer", "pub", "port", "ts", "sig"} or b["v"] != 1:
        return None
    if not isinstance(port, int) or not (0 < port < 65536) or not isinstance(ts, (int, float)):
        return None
    if abs(now - ts) > 60 or len(pub) != 32 or peer != crypto.peer_id_from_pub(pub):
        return None
    if not crypto.verify(pub, sig, b"gcp2p-lan|" + crypto.canonical(body)):
        return None
    return peer, port


class _Proto(asyncio.DatagramProtocol):
    def __init__(self, lan):
        self.lan = lan

    def datagram_received(self, data, addr):
        self.lan.on_datagram(data, addr)


class LanDiscovery:
    def __init__(self, node, bind_port: int = LAN_PORT, targets=None):
        self.node = node
        self.bind_port = bind_port
        self.targets = targets or [("255.255.255.255", LAN_PORT)]
        self.transport = None
        self.task = None
        self._last: dict[str, float] = {}

    async def start(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setblocking(False)
        sock.bind(("0.0.0.0", self.bind_port))
        loop = asyncio.get_event_loop()
        self.transport, _ = await loop.create_datagram_endpoint(lambda: _Proto(self), sock=sock)
        self.task = asyncio.ensure_future(self._loop())

    def stop(self) -> None:
        if self.task:
            self.task.cancel()
        if self.transport:
            self.transport.close()

    async def _loop(self) -> None:
        while True:
            self.beacon()
            await asyncio.sleep(BEACON_EVERY if self.node.tick_seconds >= 1 else 0.5)

    def beacon(self) -> None:
        if not self.node.listen or not self.node.port or self.transport is None:
            return
        data = make_beacon(self.node.identity, self.node.port, self.node.now())
        for t in self.targets:
            try:
                self.transport.sendto(data, t)
            except OSError:
                pass

    def on_datagram(self, data: bytes, addr) -> None:
        if len(data) > 1024:
            return
        res = parse_beacon(data, self.node.now())
        if not res:
            return
        peer, port = res
        if peer == self.node.id or peer in self.node.conns:
            return
        if self.node.now() - self._last.get(peer, 0) < 10:
            return
        self._last[peer] = self.node.now()
        if len(self.node.conns) >= 48:
            return
        self.node.spawn(self.node.get_conn(peer, [f"{addr[0]}:{port}"]))
        self.node.emit("lan_peer", {"peer": peer})
