"""Photos and videos in private chats, including view-once."""
import asyncio, os, struct, tempfile
import pytest
from helpers import run, until, make_node, stop_all
from gcp2p.messaging import media as M
from gcp2p.encryption import crypto


def jpeg(n=300_000):
    return b"\xff\xd8\xff\xe0" + os.urandom(n)


def mp4(n=700_000):
    return struct.pack(">I", 24) + b"ftypisom" + b"\0" * 12 + os.urandom(n)


async def pair(tmp):
    a = await make_node("alice", media_dir=os.path.join(tmp, "a"), storage_key=os.urandom(32))
    b = await make_node("bobby", media_dir=os.path.join(tmp, "b"), storage_key=os.urandom(32))
    await b.connect(f"127.0.0.1:{a.port}")
    assert await until(lambda: any(c.ready.is_set() for c in a.conns.values()) and any(c.ready.is_set() for c in b.conns.values()))
    await a.dm.send(b.id, "hi")                      # exchanges keys
    assert await until(lambda: b.db.dm_thread(a.id) != [])
    return a, b


def test_sniff_and_limits():
    assert M.sniff(jpeg(10)) == "image/jpeg" and M.sniff(mp4(10)) == "video/mp4"
    assert M.sniff(b"MZ\x90\x00 not media") is None and M.sniff(b"<html><script>") is None


def test_image_is_sent_downloaded_verified_and_stored_encrypted():
    async def go(tmp):
        a, b = await pair(tmp)
        data = jpeg()
        r = await a.media.send(b.id, data, "image/jpeg", False, " Lagos  trip ")
        mid = r["id"]
        assert await until(lambda: (b.media.info(mid) or {}).get("state") == "ready", 20)   # images are fetched automatically
        info = b.media.info(mid)
        assert info["caption"] == "Lagos trip" and info["size"] == len(data) and not info["once"]
        stored = open(b.media._path(mid), "rb").read()
        assert data[:64] not in stored and len(stored) > len(data)                          # encrypted at rest
        mime, got = b.media.open(mid)
        assert mime == "image/jpeg" and got == data
        assert b.media.open(mid)[1] == data                                                 # normal media can be re-opened
        assert await until(lambda: (a.media.info(mid) or {}).get("state") in ("delivered", "opened"), 15)
        assert a.media.open(mid)[1] == data                                                 # sender keeps own copy
        await stop_all(a, b)
    with tempfile.TemporaryDirectory() as t:
        run(go(t))


def test_view_once_opens_exactly_once_and_both_copies_vanish():
    async def go(tmp):
        a, b = await pair(tmp)
        data = jpeg(50_000)
        mid = (await a.media.send(b.id, data, "image/jpeg", True, ""))["id"]
        assert await until(lambda: (b.media.info(mid) or {}).get("state") == "ready", 20)
        assert await until(lambda: not os.path.exists(a.media._path(mid)), 15)              # sender deleted after delivery
        with pytest.raises(M.MediaError):
            a.media.open(mid)
        assert b.media.open(mid)[1] == data
        assert not os.path.exists(b.media._path(mid))                                        # receiver's copy is gone
        with pytest.raises(M.MediaError):
            b.media.open(mid)
        assert b.media.info(mid)["state"] == "opened"
        assert await until(lambda: (a.media.info(mid) or {}).get("state") == "opened", 15)  # sender sees "Opened"
        await stop_all(a, b)
    with tempfile.TemporaryDirectory() as t:
        run(go(t))


def test_video_waits_for_a_tap_then_downloads_in_chunks():
    async def go(tmp):
        a, b = await pair(tmp)
        data = mp4()
        mid = (await a.media.send(b.id, data, "video/mp4", False, ""))["id"]
        assert await until(lambda: b.media.info(mid) is not None, 15)
        await asyncio.sleep(1.0)
        assert b.media.info(mid)["state"] == "offered" and not b.media.info(mid)["auto"]    # no automatic big downloads
        info = await b.media.download(mid)
        assert info["state"] == "ready" and b.media.open(mid)[1] == data
        await stop_all(a, b)
    with tempfile.TemporaryDirectory() as t:
        run(go(t))


def test_rejects_wrong_type_oversize_and_disguised_files():
    async def go(tmp):
        a, b = await pair(tmp)
        for bad, mime in ((b"MZ" + os.urandom(100), "image/jpeg"), (b"<html>", "image/png"), (jpeg(10), "video/mp4")):
            with pytest.raises(M.MediaError):
                await a.media.send(b.id, bad, mime, False, "")
        with pytest.raises(M.MediaError):
            await a.media.send(b.id, jpeg(M.MAX_IMAGE + 1), "image/jpeg", False, "")
        with pytest.raises(M.MediaError):
            await a.media.send(b.id, jpeg(10), "image/jpeg", False, "<script>")
        await stop_all(a, b)
    with tempfile.TemporaryDirectory() as t:
        run(go(t))


def test_offer_validation_blocks_malformed_offers():
    async def go(tmp):
        a, b = await pair(tmp)
        good = {"v": 1, "k": "image", "m": "image/jpeg", "s": 1000, "h": "a" * 64, "o": False, "c": "", "n": 1, "fk": crypto.b64e(os.urandom(32))}
        import json
        assert b.media.on_offer(a.id, "1" * 32, json.dumps(good), b.now())
        for patch in ({"s": 10 ** 9}, {"m": "text/html"}, {"h": "zz"}, {"n": 5}, {"fk": "AAAA"}, {"k": "video"}, {"c": "<b>"}, {"o": "yes"}):
            assert not b.media.on_offer(a.id, os.urandom(16).hex(), json.dumps({**good, **patch}), b.now())
        assert not b.media.on_offer(a.id, os.urandom(16).hex(), "not json", b.now())
        await stop_all(a, b)
    with tempfile.TemporaryDirectory() as t:
        run(go(t))


def test_only_the_intended_recipient_can_pull_and_tampering_is_detected():
    async def go(tmp):
        a, b = await pair(tmp)
        c = await make_node("carol", media_dir=os.path.join(tmp, "c"), storage_key=os.urandom(32))
        await c.connect(f"127.0.0.1:{a.port}")
        assert await until(lambda: a.conns.get(c.id) is not None and a.conns[c.id].ready.is_set())
        mid = (await a.media.send(b.id, mp4(200_000), "video/mp4", False, ""))["id"]
        conn = c.conns.get(a.id)
        res = await conn.request({"t": "media_get", "id": mid, "i": 0}, timeout=5)
        assert res.get("ok") is False                                                       # a third party gets nothing
        # a sender that serves corrupted data is rejected
        orig = a.media._load
        a.media._load = lambda m: b"\xff\xd8\xff" + b"X" * 200_000
        a.media._cache.clear()
        with pytest.raises(M.MediaError):
            await b.media.download(mid)
        assert b.media.info(mid)["state"] == "offered" and not os.path.exists(b.media._path(mid))
        a.media._load = orig
        a.media._cache.clear()
        assert (await b.media.download(mid))["state"] == "ready"
        await stop_all(a, b, c)
    with tempfile.TemporaryDirectory() as t:
        run(go(t))


def test_thread_and_conversation_show_media():
    async def go(tmp):
        a, b = await pair(tmp)
        mid = (await a.media.send(b.id, jpeg(1000), "image/jpeg", True, "secret"))["id"]
        assert await until(lambda: b.db.dm_get(mid) is not None, 15)
        kinds = [m["kind"] for m in b.db.dm_thread(a.id)]
        assert "media" in kinds
        assert b.db.dm_conversations()[0]["last_kind"] == "media"
        await stop_all(a, b)
    with tempfile.TemporaryDirectory() as t:
        run(go(t))
